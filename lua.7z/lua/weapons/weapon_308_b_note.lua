AddCSLuaFile()
SWEP.PrintName = "!Note and Ideas"
SWEP.Author = "QQ3088083421"
SWEP.Category="308..' Base"

SWEP.Slot = 5
SWEP.SlotPos = 1

SWEP.Spawnable = true

SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = "models/props_c17/FurnitureDrawer001a_Shard01.mdl"
SWEP.ViewModelFOV = 80
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawCrosshair = false
SWEP.DrawAmmo = false

local max=4
function SWEP:Initialize()
self:SetHoldType("duel")
self:SetNWInt("P",1)
end

function SWEP:PrimaryAttack()
self:SetNWInt("P",self:GetNWInt("P")-1)
if self:GetNWInt("P")==0 then
self:SetNWInt("P",max)
end
end
function SWEP:SecondaryAttack()
self:SetNWInt("P",self:GetNWInt("P")+1)
if self:GetNWInt("P")>max then
self:SetNWInt("P",1)
end
end
function SWEP:Deploy()
self:SendWeaponAnim(181)
self:SetNextPrimaryFire( CurTime() )
self:SetNextSecondaryFire( CurTime() )
return true
end
SWEP.PageT=1

function SWEP:DrawHUD()
local sc=ScrW() * .5
local tc=TEXT_ALIGN_CENTER
local c=Color(15,15,15,255)
local p=self:GetNWInt("P")
local m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13
m1=" "
m2=" "
m3=" "
m4=" "
m5=" "
m6=" "
m7=" "
m8=" "
m9=" "
m10=" "
m11=" "
m13=" "
m12=" "
surface.SetDrawColor(255,255,255,155)
surface.DrawRect(0,0,ScrW(),ScrH())
surface.SetDrawColor(255,255,255,255)
if p==max-3 then
m1="如何使用? | How to use?"
m2="左/右键点击左/右翻一页"
m3="LMB/RMB to turn left/right the page"
m13="Although i don't have any model, but i'll try to keep the quality"
elseif p==max-2 then
m1="Weapon Editor"--and World Reload Anim
m2="Medkit--also use in BedWars."
m3="Skill System(Soul Knight)"
m4="Minecraft Mod to Gmod: Custom NPC--huh, but it really difficult to make this..."
m5="Boomerang   Minecraft HP Bar(a mod)"
m7=""
--How to play those games--<
--
--Undertale Game Over
--Fix Worn Dagger RMB
--类似激光反射trace.Line
--
--m4="吗啡注射器"
elseif p==max-1 then
m1="Minigame name(premade?)"
m2="SkyWars       King of the mountains"
m3="King Game      Bomb Man"
m4="The Hunter     Overlord Mode"
m5="Hide and Seek       Natural disaster"
m6="Maze   CoreWars    SkyWars:Block Area"
m7="Shooting Block    GreenShade Battlefield"
m8="SpeedRun    Dodge Ball"
m9="Trash Man    Assassin!"
elseif p==max then
m1=""
m2=" "
--m3="Return SWEP Editor   Morphine Syringe"
m4=" "
--m5="Add Minecraft Knock back"
--m6=".WAV Return .MP3   Musket    Glitchtale Scene (1 1)"
--m7="Ignore World to target(and create util.Trace)     Moving Ban shoot"
--m8="util.PrecacheSound"
m9="FlashBang+Smoke Grenade+Flare Gun"
m10=" "
--m11="NZ 幽冥毒皇"
surface.SetMaterial(Material("3088083421/timg.jpg","pixel"))surface.DrawTexturedRect(ScrW()*.3,ScrH()*.6,ScrW()*.4,ScrH()*.4)
end
local t="entcheck"
draw.SimpleText(m1, t,sc, ScrH() * .2,c,tc,tc)
draw.SimpleText(m2, t,sc, ScrH() * .23,c,tc,tc)
draw.SimpleText(m3, t,sc, ScrH() * .26,c,tc,tc)
draw.SimpleText(m4, t,sc, ScrH() * .29,c,tc,tc)
draw.SimpleText(m5, t,sc, ScrH() * .32,c,tc,tc)
draw.SimpleText(m6, t,sc, ScrH() * .35,c,tc,tc)
draw.SimpleText(m7, t,sc, ScrH() * .38,c,tc,tc)
draw.SimpleText(m8, t,sc, ScrH() * .41,c,tc,tc)
draw.SimpleText(m9, t,sc, ScrH() * .44,c,tc,tc)
draw.SimpleText(m10, t,sc, ScrH() * .47,c,tc,tc)
draw.SimpleText(m11, t,sc, ScrH() * .5,c,tc,tc)
draw.SimpleText(m12, t,sc, ScrH() * .53,c,tc,tc)
draw.SimpleText(m13, t,sc, ScrH() * .56,c,tc,tc)
end
