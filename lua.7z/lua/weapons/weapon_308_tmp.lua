SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "TMP"
SWEP.Category = "308..' Base"
SWEP.HoldType = "smg"
SWEP.ViewModel = "models/weapons/cstrike/c_smg_tmp.mdl"
SWEP.WorldModel = "models/weapons/w_smg_tmp.mdl"

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "pistol"

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.PA_Sound=""
SWEP.PA_Sound2={{Sound="weapons/tmp/tmp-1.wav"}}
SWEP.PA_Damage = 18
SWEP.PA_TakeAmmo = 1
SWEP.PA_Delay = .067
SWEP.PA_Recoil = .65
SWEP.PA_Spread = .01
SWEP.PA_AimSpread = .009
SWEP.PA_AimRecoil = .6
SWEP.SA_Delay = .1
SWEP.SA_SightFOV = 65
SWEP.SA_Cross = true
SWEP.HaveBoltPull=false

SWEP.TextType = "308CS"
SWEP.Text = "d"
SWEP.CustomAmmoIcon ="S"

SWEP.NormalDraw=true
SWEP.DrawTime = .5
SWEP.StopRAnimTime = 1.6
SWEP.ReloadTime = 1.6
SWEP.ClipoutTime = .6
SWEP.ClipinTime = 1.45
SWEP.ReloadTime2 = 1.8
SWEP.SightPos = Vector(-6.92,140,2.4)
SWEP.CenterPos = Vector(-1,100,-1)
SWEP.CenterAng = Angle(3,3,0)
