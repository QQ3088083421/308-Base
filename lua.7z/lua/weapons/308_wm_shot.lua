SWEP.PrintName    = ""
SWEP.Base = "308_wm_b"
SWEP.WorldModel="models/barney_postures.mdl"

SWEP.WElements = {
	["1"] = { type = "Model", model = "models/weapons/w_shotgun.mdl", bone = "Bip01 R Hand", rel = "", pos = Vector(16, -3, -3), angle = Angle(-189,14,180), size = Vector(1, 1, 1), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}