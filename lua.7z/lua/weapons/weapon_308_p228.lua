SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "P228"
SWEP.Category = "308..' Base"
SWEP.HoldType = "revolver"
SWEP.ViewModel = "models/weapons/cstrike/c_pist_p228.mdl"
SWEP.WorldModel = "models/weapons/w_pist_p228.mdl"

SWEP.Primary.ClipSize = 13
SWEP.Primary.DefaultClip = 13
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "pistol"

SWEP.Slot = 1
SWEP.SlotPos = 0
SWEP.Spawnable = true

SWEP.TextType="308CS"
SWEP.Text="a"
SWEP.CustomAmmoIcon ="T"

SWEP.PA_Sound = "weapons/p228/p228-1.wav"
SWEP.PA_Damage = 31
SWEP.PA_Recoil = 1
SWEP.PA_Spread = .012
SWEP.PA_AimSpread = .009
SWEP.PA_AimRecoil = .9
SWEP.SA_SightFOV = 60
SWEP.PA_Delay = .14
SWEP.SA_Delay = .1
SWEP.StopRAnimTime = 2.2
SWEP.ReloadTime = 2.3
SWEP.ClipoutTime = .85
SWEP.ClipinTime = 1.85
SWEP.ReloadTime2 = 2.7
SWEP.BoltPullTime=2.3
SWEP.BAnim="draw"

SWEP.CenterPos = Vector( 0, 70, 0 )
SWEP.CenterAng = Angle( 0, 0, 0 )
SWEP.SightPos = Vector(-5.965, 80, 2.82)
SWEP.SightAng = Angle(0,0,0)