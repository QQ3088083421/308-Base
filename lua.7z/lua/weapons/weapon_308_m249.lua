SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "M249"
SWEP.Category = "308..' Base"
SWEP.HoldType = "ar2"
SWEP.ViewModel = "models/weapons/cstrike/c_mach_m249para.mdl"
SWEP.WorldModel = "models/weapons/w_mach_m249para.mdl"

SWEP.Primary.ClipSize = 100
SWEP.Primary.DefaultClip = 100
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "smg1"

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.BSound = {
	{Delay=0,Sound="3088083421/wep/reload/mach_boltpull.ogg"}
}
SWEP.PA_Sound = "weapons/m249/m249-1.wav"
SWEP.PA_Damage = 32
SWEP.PA_TakeAmmo = 1
SWEP.PA_Force = 5
SWEP.PA_Delay = .08
SWEP.PA_Recoil = .9
SWEP.PA_Spread = .012
SWEP.PA_AimSpread = .01
SWEP.PA_AimRecoil = .7
SWEP.SA_SightFOV = 65
SWEP.TextType="308CS"
SWEP.Text="z"
SWEP.OverHeat=true
SWEP.SA_Delay = .1
SWEP.DrawTime = .5
SWEP.StopRAnimTime = 4.8
SWEP.ReloadTime = 4.8
SWEP.ClipoutTime = .75
SWEP.ClipinTime = 3.9
SWEP.ReloadTime2 = 5.8
SWEP.ReloadSound2 = {{Delay=5.2,Sound="3088083421/wep/reload/mach_boltpull.ogg"}}
SWEP.SightPos = Vector(-5.98, 60, 2.3)
SWEP.CenterPos = Vector(-2,90,1)