SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "AUG"
SWEP.Category = "308..' Base"
SWEP.HoldType = "smg"
SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.PA_Sound = ""
SWEP.PA_Sound2 = {
{Sound="weapons/aug/aug-1.wav",Volume=511}
}
SWEP.PA_Damage = 31
SWEP.ViewModel = "models/weapons/cstrike/c_rif_aug.mdl"
SWEP.WorldModel = "models/weapons/w_rif_aug.mdl"
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "smg1"
SWEP.PA_Recoil = 1
SWEP.PA_Spread = .017
SWEP.PA_Delay = .084
SWEP.PA_AimSpread = .009
SWEP.PA_AimRecoil = .7
SWEP.PA_VeloS = 800
SWEP.SA_SightFOV = 50
SWEP.SA_Delay = .4

SWEP.BSound = {
{Sound="weapons/aug/aug_boltslap.wav"}
}
SWEP.TextType="308CS"
SWEP.Text="e"
SWEP.NormalDraw = true
SWEP.SA_Cross=true
SWEP.ReloadAnimRate=1.2
SWEP.StopRAnimTime = 2.4
SWEP.BoltPullTime=2.7
SWEP.ReloadTime = 2.42
SWEP.ReloadTime2 = 3
SWEP.ClipoutTime = 1.3
SWEP.ClipinTime = 2.2

SWEP.CenterPos = Vector(0,70,0)
SWEP.CenterAng = Angle(2,0,4)
SWEP.SightPos = Vector(-4,150,3)
SWEP.SightAng = Angle(2,0,4)