SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "Five-Seven"
SWEP.Category = "308..' Base"
SWEP.HoldType = "revolver"
SWEP.ViewModel = "models/weapons/cstrike/c_pist_fiveseven.mdl"
SWEP.WorldModel = "models/weapons/w_pist_fiveseven.mdl"

SWEP.Primary.ClipSize = 20
SWEP.Primary.DefaultClip = 20
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "pistol"

SWEP.Slot = 1
SWEP.SlotPos = 0
SWEP.Spawnable = true

SWEP.TextType = "308CS"
SWEP.Text = "u"
SWEP.CustomAmmoIcon ="S"

SWEP.BAnim="draw"
SWEP.PA_Sound = "weapons/fiveseven/fiveseven-1.wav"
SWEP.PA_Damage = 20
SWEP.PA_Recoil = 1.2
SWEP.PA_Spread = .01
SWEP.PA_AimSpread = .008
SWEP.PA_AimRecoil = .9
SWEP.SA_SightFOV = 60
SWEP.PA_Delay = .09
SWEP.SA_Delay = .1
SWEP.StopRAnimTime = 2.5
SWEP.ReloadTime = 2.6
SWEP.ClipoutTime = .6
SWEP.ClipinTime = 2.1
SWEP.ReloadTime2 = 3.2
SWEP.BoltPullTime=2.5

SWEP.CenterPos = Vector( 0, 63, 0 )
SWEP.CenterAng = Angle( 0, 0, 0 )
SWEP.SightPos = Vector(-5.95, 100, 2.92)
SWEP.SightAng = Angle(0,0,0)