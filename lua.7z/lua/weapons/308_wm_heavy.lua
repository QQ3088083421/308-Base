SWEP.PrintName    = ""
SWEP.Base = "308_wm_b"
SWEP.WorldModel="models/barney_postures.mdl"

SWEP.WElements = {
	["1"] = { type = "Model", model = "models/weapons/w_mach_m249para.mdl", bone = "Bip01 R Hand", rel = "", pos = Vector(12, -2, -3), angle = Angle(3,12, 0), size = Vector(1, 1, 1), color = Color(255, 255,0), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}