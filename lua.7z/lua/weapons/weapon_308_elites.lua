SWEP.Base = "weapon_308_basedual"
SWEP.PrintName=GAME308_LANWEP["double"].."Beretta"
SWEP.Category = "308..' Base"
SWEP.HoldType = "duel"
SWEP.ViewModel = "models/weapons/cstrike/c_pist_elite.mdl"
SWEP.WorldModel = "models/weapons/w_pist_elite.mdl"
SWEP.SwayScale = 4
SWEP.Slot=1
SWEP.Spawnable=true
SWEP.StopRAnimTime = 2.9
SWEP.DrawSound={{Sound="3088083421/wep/deploy/deploy_cod_2.wav"}}
SWEP.PA_Sound = "weapons/elite/elite-1.wav"
SWEP.TextType = "308CS"
SWEP.Text = "s"
