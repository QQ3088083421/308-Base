AddCSLuaFile()
local function CN()if system.GetCountry()=="CN"||system.GetCountry()=="HK"||system.GetCountry()=="TW"||system.GetCountry()=="TC" then return 1 end end
SWEP.PrintName = "!"..GAME308_LANWEP["b_wb"]
SWEP.Author = "QQ3088083421"
SWEP.Category="308..' Base"

SWEP.Slot = 5
SWEP.SlotPos = 1

SWEP.Spawnable = true

SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = "models/props_c17/FurnitureDrawer001a_Shard01.mdl"
SWEP.ViewModelFOV = 80
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawCrosshair = false
SWEP.DrawAmmo = false
SWEP.WElements = {
	["1+"] = { type = "Model", model = "models/squad/sf_plates/sf_plate1x1.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "1", pos = Vector(0, 0, 0.699), angle = Angle(0, 0, 115), size = Vector(1, 1, 0.009), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/xqm/jetbody2tailpiece_diffuse", skin = 0, bodygroup = {} },
	["1"] = { type = "Model", model = "models/squad/sf_plates/sf_plate1x1.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(4.613, 12.666, -11.936), angle = Angle(82.829, -110.02, -1.259), size = Vector(1, 0.079, 1), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/xqm/jetbody2tailpiece_diffuse", skin = 0, bodygroup = {} },
	["1++"] = { type = "Model", model = "models/squad/sf_plates/sf_plate1x1.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "1", pos = Vector(0, 0, 0.699), angle = Angle(0, 0, -115), size = Vector(1, 1, 0.009), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/xqm/jetbody2tailpiece_diffuse", skin = 0, bodygroup = {} }
}
function SWEP:Initialize()
self:SetHoldType("duel")
self:SetNWInt("P",1)
end

local max=20
function SWEP:PrimaryAttack()
self:SetNWInt("P",self:GetNWInt("P")-1)
if self:GetNWInt("P")==0 then
self:SetNWInt("P",max)
end
end
function SWEP:SecondaryAttack()
self:SetNWInt("P",self:GetNWInt("P")+1)
if self:GetNWInt("P")>max then
self:SetNWInt("P",1)
end
end
function SWEP:Deploy()
self:SendWeaponAnim(181)
self:SetNextPrimaryFire( CurTime() )
self:SetNextSecondaryFire( CurTime() )
return true
end
SWEP.PageT=1
function SWEP:DrawHUD()
local m=self.Owner:EyeAngles().pitch
local sc=ScrW()*(.51+m/250)
local tc=TEXT_ALIGN_CENTER
local c=Color(15,15,15,255)
local p=self:GetNWInt("P")
local m1,m2,m3,m4,m5,m6,m7,m8,m9,t
m1=" "
m2=" "
m3=" "
m4=" "
m5=" "
m6=" "
m7=" "
m8=" "
m9=" "
surface.SetDrawColor(255,255,255,155)
surface.DrawRect(0,0,ScrW(),ScrH())
if p==max-19 then
m1="如何使用? | How to use?"
m2="左/右键点击左/右翻一页"
m3="LMB/RMB to turn left/right the page"
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p3.png","smooth"))surface.DrawTexturedRect(0,ScrH()*.4, 250, 300 )
draw.SimpleText("Don't Forget it || 不要忘记了:c", "entcheck",0,ScrH()*.38,c,tl,tc)
m4="上下移动视角以查看更多的文字"
m5="Move the perspective up and down to see more text"
t="2020/7/?"
elseif p==max-18 then
m1="4/16"
if CN()then
m1="=取消跑步时的右键瞄准="
m2="=取消跑步中的右键瞄准="
else
m1="=Cancel RMB aim when sprinting"
end
t="2021/4/16"
elseif p==max-17 then
m1="2/X"
if CN()then
m1="=修复多人游戏中的射击时视角晃动异常?="
m2="=更好的动画Base="
m3="=修复在防护衣缩放和瞄准下半自动武器"
m4="可以变成全自动武器的BUG="
m5="=添加Nextbot感染="
else
m1="=Fix abnormal angle of view shaking"
m2="when shoot on multiplayer="
m3="=Better Animated Base="
m4="=Fix bug that semi-automatic weapon can be turned into"
m5="full-automatic weapon when the protective clothing zooms and aims="
m6="=Add Nextbot Infection="
end
t="2021/2/X"
elseif p==max-16 then
m1="1/17"
if CN()then
m1="=添加横扫="
m2="=添加远程武器近战="
m3="=修复RPG Overworld test卡顿="
else
m1="=Add Swing="
m2="=Add long range weapon melee="
m3="=Fix RPG Overworld test lag="
end
t="2021/1/17"
elseif p==max-15 then
m1="11/14"
if CN()then
m1="=修复持握姿势="
m2="=步行抖动优化="
else
m1="=Fix Hold Type="
m2="=Better Moving Shake="
end
t="2020/11/14"
elseif p==max-14 then
m1="8/30"
if CN()then
m2="=优化龙骨炮痕迹判断="
else
m2="=Optimization Gaster Blaster Trace Judge="
end
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/1.png","smooth"))surface.DrawTexturedRect(ScrW()*.43,ScrH()*.36,ScrH()*.9,ScrH()*.4)
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/2.png","smooth"))surface.DrawTexturedRect(ScrW()*.1,ScrH()*.36,ScrW()*.26,ScrH()*.16)
t="2020/8/30"
elseif p==max-13 then
m1="8/19"
if CN()then
m2="=持续修复一些BUG="
m3="=添加战役I="
m4="=更好的双持武器="
m5="=现在NextBot有关系网了!"
m6="同时,新增3个关系网模式="
else
m2="=Continue fix some BUGs="
m3="=Add Campaign I="
m4="=Better Dual Weapons="
m5="=NextBot have Relationships Net now!"
m6="and Add 3 Relationships Net mode!(it will playing well)="
end
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("entities/obj_308_ca1.png","smooth"))surface.DrawTexturedRect(0,ScrH()*.1,300,300)
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p13.png","smooth"))surface.DrawTexturedRect(ScrW()*.7,ScrH()*.6,250,200)
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p14.png","smooth"))surface.DrawTexturedRect(ScrW()*.5,ScrH()*.2,250,250)
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p15.png","smooth"))surface.DrawTexturedRect(ScrW()*.7,ScrH()*.2,250,250)
t="2020/8/19"
elseif p==max-12 then
m1="8/4~7/28"
if CN()then
m2="=持续修复一些BUG="
m3="=现在NextBot可以兼容CPT Base了="
m4="(如果先生成NextBot再生成NPC，NPC可能不会主动攻击(也可能永不攻击..))"
else
m2="=Continue fix some BUGs="
m3="=Now nextbots can compatible CPT Base="
m4="(if you first spawn NPC then spawn nextbot, NPC maybe won't attack nextbot)"
end
t="2020/8/4"
elseif p==max-11 then
m1="7/18"
if CN()then
m2="这次更新就一个迷你游戏:起床战争..."
m3="你去玩就知道了，真够肝的，毕竟又不是游戏模式"
m4="顺带，致敬MC"
m5="修复饥饿游戏"
else
m2="this update just a minigame:BedWars..."
m3="You'll know when you go and play, after all its not is a gamemode"
m4="Fix Hunger Game"
end
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("entities/obj_308_bedwar.png","smooth"))surface.DrawTexturedRect(100,ScrH()*.5,300,300)
t="2020/7/18"
elseif p==max-10 then
m1="7/4"
if CN()then
m2="=更好的NextBot="
m3="咳...这几天我为\"我的世界\"提供"
m4="一个更好的动画基础...所以目前基本先这样了"
m5="(你可以把你的玩家模型应用到他们身上:D)"
else
m2="=Better NextBot="
m3="Err...these days i make a better animation base"
m4="for \"Minecraft\", it taken my week..."
m5="(You can apply your player model in them :D)"
end
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p12.png","smooth"))surface.DrawTexturedRect(100,ScrH()*.5,200,300)
surface.SetMaterial(Material("3088083421/p6.png","smooth"))surface.DrawTexturedRect(300,ScrH()*.5,300,300)
t="2020/7/4"
elseif p==max-9 then
m1="6/27"
if CN()then
m2="一些NPC会在Idle状态时与附近的NPC聊天"
m3="修复一批多人游戏中的问题(不排除没修好)"
m4="现在其它的NPC会反击了"
else
m2="=Some NPCs will communicate with"
m3="other if they on idle status="
m4="Fix problems in a group of multiplayer games"
m5="(Some problems maybe not solved)"
m6="Other SNPCs will strike back now"
end
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p10.png","smooth"))surface.DrawTexturedRect(0,ScrH()*.5,300,300)
surface.SetMaterial(Material("3088083421/p11.png","smooth"))surface.DrawTexturedRect(300,ScrH()*.5,300,300)
t="2020/6/27"
elseif p==max-8 then
m1="6/22~6/19"
if CN()then
m2="更好的迷你小游戏"
m3="修复一批多人游戏中的问题(不排除没修好)"
m4="更好的NextBot"
else
m2="Better Minigame"
m3="Fix problems in a group of multiplayer games"
m4="(Some problems maybe not solved)"
m5="Better NextBot"
end
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p7.png","smooth"))surface.DrawTexturedRect(0,ScrH()*.5,300,300)
surface.SetMaterial(Material("3088083421/p8.png","smooth"))surface.DrawTexturedRect(300,ScrH()*.5,300,300)
surface.SetMaterial(Material("3088083421/p9.png","smooth"))surface.DrawTexturedRect(600,ScrH()*.5,300,300)
t="2020/6/22"
elseif p==max-7 then
m1="5/25"
if CN()then
draw.SimpleText("(但是一般情况下NPC不会反击: |)", "entcheck",ScrW()*.8,ScrH()*.3,c,tc,tc)
m2="=会主动攻击其它NextBot和NPC="
m3="=修复并完善换弹="
m4="=更好的小游戏出错关闭报告="
m5="=修复一些不用子弹的武器"
m6="多人游戏中会发射子弹的Bug="
else
draw.SimpleText("(BUT normally NPCs won't strike back : |)", "entcheck",ScrW()*.8,ScrH()*.19,c,tc,tc)
m2="=Will attack other nextbots and NPCs="
m3="=Repair and improve Reloading="
m4="=Better minigame error delete Report="
m5="=Repair some weapons unuse bullet but"
m6="can shoot bullet on multiplayer="
end
t="2020/5/25"
elseif p==max-6 then
m1="5/16"
draw.SimpleText("<--", "308wepbase",ScrW()*.3,ScrH()*.64,Color(215,215,215,255),tc,tc)
surface.SetDrawColor(255,255,255,255)surface.SetMaterial(Material("3088083421/p4.png","smooth"))surface.DrawTexturedRect(0,ScrH()*.5,300,300)
if CN()then
draw.SimpleText("修复游戏时有人使用C/Q键菜单作弊问题(诚信游戏)", "308wepbase",ScrW() * (.51+math.Rand(-.001,.001)), ScrH() * (.23+math.Rand(-.001,.001)),c,tc,tc)
m3=".添加更多选项"
m4=".拔出的弹夹会掉落(需要你去设置)"
m5=".更好的翻译"
else
draw.SimpleText("Fix use context menu or spawn menu to cheat", "308wepbase",ScrW() * (.51+math.Rand(-.001,.001)), ScrH() * (.23+math.Rand(-.001,.001)),c,tc,tc)
draw.SimpleText("when someone gaming(Integrity game)", "308wepbase",ScrW() * (.51+math.Rand(-.001,.001)), ScrH() * (.3+math.Rand(-.001,.001)),c,tc,tc)
m4=".Add More Options"
m5=".Unload Clip(or Bullets) will drop"
m6=".Better Translate"
end
t="2020/5/16"
elseif p==max-5 then
m1="5/1"
m2="Add Options|添加选项"
m3="Better Melee|更好的近战"
m4="Better Translate|更好的翻译"
t="2020/5/1"
elseif p==max-4 then
m1="4/17"
m2="Allow toggle HUD|允许切换HUD"
m3="Fix SG552 Bullets spread while walking"
m4="修复SG552走路时的子弹扩散"
m5="Add Nextbot|添加Nextbot"
m6="Gunfire can be heard by npcs|NPC可以听到枪声"
t="2020/4/17"
elseif p==max-3 then
m1="4/3"
m2="Add Tracer|添加曳光"
t="2020/4/3"
elseif p==max-2 then
m1="3/27"
m2="Fix Running FOV|修复跑步视野"
m3="Add New Details|添加新的细节"
m5="Fix PUBG|修复PUBG"
t="2020/3/27"
elseif p==max-1 then
m1="3/21"
m2="Add weapon bobing|添加武器摇摆"
t="2020/3/21"
elseif p==max then
m1="Hidden Weapon List|隐藏武器列表"
m2="M9K Assault Rifle - 1"
m3="TFA CSO Part 4 - 1"
m4="[DSB]Halo SWEP Collection - 3"
m5="Half Life:Source-Content - 5"
m6="Vaporize Pistol - 1"
m7="Cry of Fear Weapon Pack - 1"
m8="VJ Base(or Black Mesa: Source Weapon Pack)- 1"
m9="CrossFire Source Weapon Content- >12"
surface.SetDrawColor(255,255,255,255)
surface.SetMaterial(Material("3088083421/p01.png","smooth"))
surface.DrawTexturedRect( 1, 1, 200, 200 )
surface.SetMaterial(Material("3088083421/p02.png","smooth"))
surface.DrawTexturedRect( 1, 210, 200, 200 )
if CN()then
m9="你们订阅后就可以看到武器了:>"
else
m9="You can see these when you subscribe"
end
t="2020/5/3"
end
draw.SimpleText("第"..p.."页[Page :"..p.."]", "308wepbase", ScrW() * .5, ScrH() * .05,c,tc,tc)

draw.SimpleText(m1, "308wepbase",sc, ScrH() * .13,c,tc,tc)
draw.SimpleText(m2, "308wepbase",sc, ScrH() * .23,c,tc,tc)
draw.SimpleText(m3, "308wepbase",sc, ScrH() * .3,c,tc,tc)
draw.SimpleText(m4, "308wepbase",sc, ScrH() * .37,c,tc,tc)
draw.SimpleText(m5, "308wepbase",sc, ScrH() * .44,c,tc,tc)
draw.SimpleText(m6, "308wepbase",sc, ScrH() * .51,c,tc,tc)
draw.SimpleText(m7, "308wepbase",sc, ScrH() * .58,c,tc,tc)
draw.SimpleText(m8, "308wepbase",sc, ScrH() * .65,c,tc,tc)
draw.SimpleText(m9, "308wepbase",sc, ScrH() * .73,c,tc,tc)
draw.SimpleText("写于|Write at :"..t, "308wepbase",sc, ScrH() * .8,c,tc,tc)
end
