SWEP.Base = "weapon_308_block"
SWEP.PrintName=GAME308_LANWEP["block"].."(Create)"
SWEP.Category = "308..' Base"
SWEP.ViewModel = "models/weapons/v_pistol.mdl"
SWEP.WorldModel = "models/props_junk/wood_crate001a_damaged.mdl"
SWEP.Spawnable=true
SWEP.CreateM=1
