
AddCSLuaFile()

SWEP.PrintName = GAME308_LANWEP["damget"]
SWEP.Author = "QQ3088083421"
SWEP.Category = "308..' Base"

SWEP.Slot = 0
SWEP.SlotPos = 4

SWEP.AdminOnly=true
SWEP.Spawnable = true

SWEP.ViewModel = Model( "models/weapons/c_toolgun.mdl" )
SWEP.WorldModel = "models/weapons/w_toolgun.mdl"
SWEP.ViewModelFOV = 54
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawAmmo = false
SWEP.time = CurTime()

function SWEP:SetupDataTables()
self:NetworkVar( "Float", 1, "NextIdle" )
end

function SWEP:PlayAnim(an,br)
local vm = self.Owner:GetViewModel()
vm:SendViewModelMatchingSequence( vm:LookupSequence( an ) )
vm:SetPlaybackRate(br)
self:SetNextIdle( CurTime() + vm:SequenceDuration() / br )
end

function SWEP:Initialize()
self:SetHoldType( "pistol" )
self:SetNetworkedString("D",0)
self:SetNetworkedString("E",0)
end

function SWEP:UpdateNextIdle()

	local vm = self.Owner:GetViewModel()
	self:SetNextIdle( CurTime() + vm:SequenceDuration() / vm:GetPlaybackRate() )

end

function SWEP:DoShootEffect( hitpos, hitnormal, entity, physbone, bFirstTimePredicted )

	self:PlayAnim("fire01",1.5)
	local effectdata = EffectData()
	effectdata:SetOrigin( hitpos )
	effectdata:SetNormal( hitnormal )
	effectdata:SetEntity( entity )
	effectdata:SetAttachment( physbone )
	util.Effect( "selection_indicator", effectdata )

	effectdata = EffectData()
	effectdata:SetOrigin( hitpos )
	effectdata:SetStart( self.Owner:GetShootPos() )
	effectdata:SetAttachment( 1 )
	effectdata:SetEntity( self )
	util.Effect( "ToolTracer", effectdata )

end

function SWEP:PrimaryAttack( right )
local tr = util.GetPlayerTrace( self.Owner )
tr.mask = bit.bor( CONTENTS_SOLID, CONTENTS_MOVEABLE, CONTENTS_MONSTER, CONTENTS_WINDOW, CONTENTS_DEBRIS, CONTENTS_GRATE, CONTENTS_AUX )
local trace = util.TraceLine( tr )
if ( !trace.Hit ) then return end
self:DoShootEffect( trace.HitPos, trace.HitNormal, trace.Entity, trace.PhysicsBone, IsFirstTimePredicted() )
self:UpdateNextIdle()
self:SetNextPrimaryFire( CurTime() )
self:SetNextSecondaryFire( CurTime() )
if SERVER && IsValid( trace.Entity ) then
local d = DamageInfo()
d:SetDamage(self:GetNetworkedString("D"))
if !self.Owner:IsAdmin() then
self:SetNextPrimaryFire( CurTime()+1 )
self:SetNextSecondaryFire( CurTime()+1 )
if self:GetNetworkedString("D") >= 50 then d:SetDamage(50) end
end
d:SetDamageType(DMG_BULLET)
d:SetAttacker(self.Owner)
d:SetInflictor(self.Owner)
trace.Entity:TakeDamageInfo(d)
end
self.Owner:LagCompensation( false )
end

function SWEP:SecondaryAttack()
local tr = util.GetPlayerTrace( self.Owner )
tr.mask = bit.bor( CONTENTS_SOLID, CONTENTS_MOVEABLE, CONTENTS_MONSTER, CONTENTS_WINDOW, CONTENTS_DEBRIS, CONTENTS_GRATE, CONTENTS_AUX )
local trace = util.TraceLine( tr )
if ( !trace.Hit ) then return end
self:UpdateNextIdle()
self:SetNextPrimaryFire( CurTime() )
self:SetNextSecondaryFire( CurTime() )
if !self.Owner:IsAdmin() then self.Owner:PrintChat("===WARNING:REFUSE USE===") self.Owner:PrintChat(" ===BLOCK A ERROR===") return end
self:DoShootEffect( trace.HitPos, trace.HitNormal, trace.Entity, trace.PhysicsBone, IsFirstTimePredicted() )
if SERVER && IsValid( trace.Entity ) then
local d = DamageInfo()
d:SetDamage(10^99)
d:SetDamageType(DMG_SHOCK)
d:SetAttacker(trace.Entity)
d:SetInflictor(trace.Entity)
self:EmitSound("weapons/c4/c4_plant.wav")
sound.Play("weapons/c4/c4_explode1.wav",trace.Entity:GetPos())
trace.Entity:TakeDamageInfo(d)
else self:EmitSound("weapons/c4/c4_beep1.wav")
end
self.Owner:LagCompensation( false )
end

function SWEP:Reload()
self:PlayAnim("reload",5)
if self:GetNetworkedString("D") <= 5100 then self:SetNetworkedString("D",self:GetNetworkedString("D")+10)
elseif self:GetNetworkedString("D") <= 10100 then self:SetNetworkedString("D",self:GetNetworkedString("D")+20)
elseif self:GetNetworkedString("D") <= 50500 then self:SetNetworkedString("D",self:GetNetworkedString("D")+50)
elseif self:GetNetworkedString("D") > 50500 then self:SetNetworkedString("D",self:GetNetworkedString("D")+100)
end
self:EmitSound("weapons/c4/c4_click.wav")
end

function SWEP:OnDrop()
end

function SWEP:Deploy()
self:SetNextPrimaryFire( CurTime()+0.1 )
self:SetNextSecondaryFire( CurTime()+0.1 )
self:PlayAnim("draw",1)
if self:GetNetworkedString("E") == 0 then self:SetNetworkedString("D",10) end
self:UpdateNextIdle()
return true
end

function SWEP:Think()
if self.Owner:KeyDown(IN_USE) and self.time < CurTime() then self.time = CurTime() +0.5 self:EmitSound("weapons/c4/c4_beep1.wav")
if self:GetNetworkedString("E") == 0 then self:SetNetworkedString("E",1)
else self:SetNetworkedString("E",0)
end
end

local idletime = self:GetNextIdle()
if ( idletime > 0 && CurTime() > idletime ) then
if math.random(2) then self:PlayAnim("idle01",1) else self:PlayAnim("reload",0.85) end
self:UpdateNextIdle()
end
end

function SWEP:DrawHUD() -- HUD Thanks for Jereapieya.
local a = self:GetNetworkedString("D")
local b = self:GetNetworkedString("E")

draw.SimpleText(GAME308_LANWEP["damget1"], "entcheck", ScrW() * 0.01, ScrH() * 0.8, Color( 255, 99, 99, 255 ), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
draw.SimpleText(GAME308_LANWEP["damget2"], "entcheck", ScrW() * 0.01, ScrH() * 0.83, Color( 255, 99, 99, 255 ), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
draw.SimpleText(GAME308_LANWEP["damget3"]..b.."   "..GAME308_LANWEP["damget4"]..a, "entcheck", ScrW() * 0.01, ScrH() * 0.9, Color( 255, 99, 99, 255 ), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
end
