SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "UMP45"
SWEP.Category = "308..' Base"
SWEP.HoldType = "smg"
SWEP.ViewModel = "models/weapons/cstrike/c_smg_ump45.mdl"
SWEP.WorldModel = "models/weapons/w_smg_ump45.mdl"

SWEP.Primary.ClipSize = 25
SWEP.Primary.DefaultClip = 25
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "pistol"

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.NormalDraw = true
SWEP.BSound = {
{Sound="weapons/sg550/sg550_boltpull.wav"}
}
SWEP.PA_Sound = "weapons/ump45/ump45-1.wav"
SWEP.PA_Damage = 30
SWEP.PA_Delay = .099
SWEP.PA_Recoil = 1
SWEP.PA_Spread = .02
SWEP.PA_AimSpread = .016
SWEP.PA_AimRecoil = .8
SWEP.SA_SightFOV = 65

SWEP.TextType = "308CS"
SWEP.Text = "q"
SWEP.CustomAmmoIcon ="M"

SWEP.SA_Delay = .1
SWEP.DrawTime = .5
SWEP.StopRAnimTime = 2.4
SWEP.ReloadTime = 2.5
SWEP.BoltPullTime=2.6
SWEP.ClipoutTime = .7
SWEP.ClipinTime =2
SWEP.ReloadTime2 = 3.4
SWEP.SightPos = Vector(-8.73, 110, 4.29)
SWEP.SightAng = Angle(-1.3, -.13, 0)
SWEP.CenterPos = Vector(-3,80,1)
