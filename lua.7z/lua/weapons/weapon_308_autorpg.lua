SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName=GAME308_LANWEP["autorpg"]
SWEP.Category = "308..' Base"
SWEP.HoldType = "rpg"
SWEP.ViewModel = "models/weapons/c_rpg.mdl"
SWEP.WorldModel = "models/weapons/w_rocket_launcher.mdl"
SWEP.MaxBobScale = 2400

SWEP.PA_Num=0
SWEP.Primary.ClipSize = 12
SWEP.Primary.DefaultClip = 12
SWEP.Primary.Ammo = "RPG_Round"
SWEP.Primary.Automatic=true

SWEP.Slot = 4
SWEP.Spawnable = true
SWEP.DrawSound = {}
SWEP.PA_Sound = ""
SWEP.PA_Delay = .8
SWEP.PA_Recoil = 0
SWEP.PA_AimRecoil = 0

SWEP.NoPullClip=true
SWEP.SA_Delay = .1
SWEP.ClipExtraBullet = false
SWEP.NormalDraw=true
SWEP.Text_Auto="Rocket"
SWEP.BlockPrimary=true
SWEP.ReloadSound = {
{Sound="3088083421/wep/carry/ava1.ogg"},
{Delay=.5,Sound="3088083421/wep/reload/mach_clipout.ogg"},
{Delay=.8,Sound="3088083421/wep/reload/all_boltpull.ogg"},
{Delay=1.1,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=110},
{Delay=1.4,Sound="3088083421/wep/reload/all_boltpull.ogg"},
{Delay=1.7,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=90},
{Delay=2.1,Sound="3088083421/wep/reload/mach_coverdown.ogg"},
}
SWEP.ReloadSound2 = {
{Sound="3088083421/wep/carry/ava1.ogg",Pitch=120},
{Delay=.5,Sound="3088083421/wep/reload/mach_clipout.ogg"},
{Delay=1,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=90},
{Delay=1.2,Sound="3088083421/wep/reload/all_boltpull.ogg"},
{Delay=1.4,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=90},
{Delay=1.6,Sound="3088083421/wep/reload/all_boltpull.ogg"},
{Delay=1.8,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=90},
{Delay=2,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=90},
{Delay=2.2,Sound="3088083421/wep/reload/all_boltpull.ogg"},
{Delay=2.4,Sound="3088083421/wep/reload/all_boltpull.ogg",Pitch=90},
{Delay=2.9,Sound="3088083421/wep/reload/mach_coverdown.ogg"},
{Delay=3.2,Sound="3088083421/wep/reload/all1_boltpull.wav"},
}
SWEP.ClipoutTime=.7
SWEP.ClipinTime=1.8
SWEP.ClipinTime2=3.1
SWEP.StopRAnimTime = 2.2
SWEP.ReloadAnimRate = .5
SWEP.ReloadTime = 2.3
SWEP.ReloadTime2 = 3.2
SWEP.SightPos = Vector(-8, 210, -.4)
SWEP.CenterPos = Vector(-7, 200, -.4)

function SWEP:CustomPrimary()

	for i=1,math.Clamp(self:Clip1()+self.PA_TakeAmmo,1,3) do
	timer.Simple(i/8,function()if IsValid(self)then
	if SERVER then
	if i>1 then self:TakePrimaryAmmo(self.PA_TakeAmmo)end
	self:EmitSound("3088083421/wep/shoot/rpg_1.ogg",511,120)
	self:SendWeaponAnim(self.PA_Anim)
	local e=ents.Create("obj_308_autoroc")
	local aim = self.Owner:GetAimVector()
	local side = aim:Cross(Vector(0,0,1))
	local pos = self.Owner:GetShootPos()+self:GetForward()*30+self:GetRight()*9-self:GetUp()*4
	if !e:IsValid() then return false end
	e:SetAngles(self.Owner:GetAimVector():Angle())
	e:SetPos(pos)
	e:SetOwner(self.Owner)
	e:Spawn()
	e.Owner = self.Owner
	e:Activate()
	self.Owner:DeleteOnRemove(e)--you know why.
	e:SetVelocity(self.Owner:GetForward()*(i*80+100)+self.Owner:GetUp()*(400-i*70)+self.Owner:GetVelocity()/2)
	end
	end end)

	end

end