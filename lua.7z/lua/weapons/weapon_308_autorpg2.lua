SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName=GAME308_LANWEP["autorpg2"]
SWEP.AdminOnly=true
SWEP.DrawCross=false
SWEP.Category = "308..' Base"
SWEP.HoldType = "rpg"
SWEP.ViewModel = "models/weapons/c_rpg.mdl"
SWEP.WorldModel = "models/weapons/w_rocket_launcher.mdl"
SWEP.MaxBobScale = 2400

SWEP.PA_Num=0
SWEP.Primary.ClipSize = 16
SWEP.Primary.DefaultClip = 16
SWEP.Primary.Ammo = "RPG_Round"
SWEP.Primary.Automatic=true

SWEP.Slot = 4
SWEP.Spawnable = true
SWEP.DrawSound = {}
SWEP.PA_Sound = ""
SWEP.PA_Delay = .15
SWEP.PA_Recoil = .1
SWEP.PA_AimRecoil = .1

SWEP.NoPullClip=true
SWEP.SA_Delay = .1
SWEP.ClipExtraBullet = false
SWEP.NormalDraw=true
SWEP.Text_Auto="Rocket"
SWEP.PA_DryFireSound = "npc/scanner/combat_scan3.wav"
SWEP.ReloadSound = {
{Sound="vehicles/tank_readyfire1.wav",Pitch=90}
}
SWEP.ReloadSound2 = {
{Sound="npc/scanner/cbot_discharge1.wav"},
{Delay=.5,Sound="3088083421/wep/reload/mach_clipout.ogg",Pitch=110},
{Delay=1,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=1.2,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=1.4,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=1.6,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=1.8,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=2,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=2.2,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=2.4,Sound="3088083421/wep/reload/rpg_rocin.ogg"},
{Delay=2.9,Sound="3088083421/wep/reload/mach_coverdown.ogg",Pitch=90},
}
SWEP.ClipoutTime=.7
SWEP.ClipinTime=1.8
SWEP.ClipinTime2=3.1
SWEP.StopRAnimTime = 2.2
SWEP.ReloadAnimRate = .5
SWEP.ReloadTime = 2.3
SWEP.ReloadTime2 = 3.2
SWEP.SightPos = Vector(-10.2, 150, -4.5)
SWEP.CenterPos = Vector(-2, 180, -7)
SWEP.WElements = {
	["1++"] = { type = "Model", model = "models/props_combine/combine_window001.mdl", bone = "base", rel = "1+", pos = Vector(1, 0, .751), angle = Angle(-105, 0, 0), size = Vector(0.05, 0.05, 0.05), color = Color(0, 0, 0, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} },
	["1+"] = { type = "Model", model = "models/props_c17/oildrum001.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(6, 1.3, -6.9), angle = Angle(-135, 76, 73), size = Vector(0.244, 0.244, 0.244), color = Color(37, 89, 42, 255), surpresslightning = false, material = "metal2a", skin = 0, bodygroup = {} },
	["1"] = { type = "Model", model = "models/props_combine/combine_window001.mdl", bone = "base", rel = "1+", pos = Vector(3, 0, 13), angle = Angle(-105, 0, 0), size = Vector(0.05, 0.05, 0.05), color = Color(0, 0, 0, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} },
	["2"] = { type = "Sprite", sprite = "sprites/orangecore2", bone = "ValveBiped.Bip01_Spine4", rel = "1", pos = Vector(0, 0, 4.623), size = { x = 0.453, y = 0.453 }, color = Color(255, 0, 0, 255), nocull = true, additive = true, vertexalpha = true, vertexcolor = true, ignorez = false}
}
SWEP.VElements = {
	["1++"] = { type = "Model", model = "models/props_combine/combine_window001.mdl", bone = "base", rel = "1+", pos = Vector(3, 0, -0.751), angle = Angle(-105, 0, 0), size = Vector(0.05, 0.05, 0.05), color = Color(0, 0, 0, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} },
	["1+"] = { type = "Model", model = "models/props_c17/oildrum001.mdl", bone = "base", rel = "", pos = Vector(-0.802, -0.087, 12.901), angle = Angle(0, 45, 0), size = Vector(0.244, 0.244, 0.244), color = Color(37, 89, 42, 255), surpresslightning = false, material = "metal2a", skin = 0, bodygroup = {} },
	["1"] = { type = "Model", model = "models/props_combine/combine_window001.mdl", bone = "base", rel = "1+", pos = Vector(5, 0, 14), angle = Angle(-105, 0, 0), size = Vector(0.05, 0.05, 0.05), color = Color(0, 0, 0, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} },
	["2"] = { type = "Sprite", sprite = "sprites/orangecore2", bone = "ValveBiped.Bip01_Spine4", rel = "1", pos = Vector(0, 0, 4.623), size = { x = 0.453, y = 0.453 }, color = Color(255, 0, 0, 255), nocull = true, additive = true, vertexalpha = true, vertexcolor = true, ignorez = false},
	["2+"] = { type = "Sprite", sprite = "sprites/physcannon_bluecore2b", bone = "ValveBiped.Bip01_Spine4", rel = "1", pos = Vector(15.654, 0, 8.831), size = { x = 1.691, y = 1.691 }, color = Color(0, 0, 255, 206), nocull = true, additive = true, vertexalpha = true, vertexcolor = true, ignorez = false}
}
function SWEP:CustomPrimary()
	if SERVER then
	self.Owner:EmitSound("npc/env_headcrabcanister/launch.wav",511,49+math.random(101))
	if self.Scope<1 then self:PlayAnim2(self.PA_Anim,1,.5)else self:PlayAnim2(self.PA_Anim,2,.1)end
	local e=ents.Create("obj_308_autoroc")
	local aim = self.Owner:GetAimVector()
	local pos = self.Owner:GetShootPos()+self:GetForward()*30+self:GetRight()*9-self:GetUp()*6
	if !e:IsValid() then return false end
	e:SetAngles(self.Owner:GetAimVector():Angle())
	e:SetPos(pos)
	e:SetOwner(self.Owner)
	e:Spawn()
	e.Owner = self.Owner
	e:Activate()
	self.Owner:DeleteOnRemove(e)--you know why.
	e:SetVelocity(self.Owner:GetForward()*200+Vector(0,0,150)+self.Owner:GetVelocity()/2)
	end
end