SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "MP5 Navy"
SWEP.Category = "308..' Base"
SWEP.HoldType = "smg"
SWEP.ViewModel = "models/weapons/cstrike/c_smg_mp5.mdl"
SWEP.WorldModel = "models/weapons/w_smg_mp5.mdl"

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "pistol"

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.PA_Sound = "weapons/mp5navy/mp5-1.wav"
SWEP.PA_Damage = 25
SWEP.PA_Delay = .07
SWEP.PA_Recoil = .6
SWEP.PA_Spread = .02
SWEP.PA_AimSpread = .015
SWEP.PA_AimRecoil = .54
SWEP.SA_SightFOV = 70

SWEP.TextType = "308CS"
SWEP.Text = "x"

SWEP.ReloadAnimRate=1.1
SWEP.ReloadAnim="reload1"
SWEP.BAnim="draw"
SWEP.SA_Delay = .1
SWEP.DrawTime = .5
SWEP.StopRAnimTime = 1.8
SWEP.ReloadTime = 1.9
SWEP.ClipoutTime = .5
SWEP.ClipinTime = 1.5
SWEP.ReloadTime2 = 2.6
SWEP.BoltPullTime=2.1
SWEP.SightPos = Vector(-5.35, 160, 2.45)
SWEP.CenterPos = Vector(-1,80,1)