SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "Galil"
SWEP.Category = "308..' Base"
SWEP.HoldType = "ar2"
SWEP.ViewModel = "models/weapons/cstrike/c_rif_galil.mdl"
SWEP.WorldModel = "models/weapons/w_rif_galil.mdl"
SWEP.CSMuzzleFlashes = true
SWEP.Primary.ClipSize = 35
SWEP.Primary.DefaultClip = 35
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "smg1"
SWEP.NormalDraw = true

SWEP.TextType = "308CS"
SWEP.Text = "v"

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.BSound = {{Sound="weapons/galil/galil_boltpull.wav"}}
SWEP.PA_Sound = "weapons/galil/galil-1.wav"
SWEP.PA_Damage = 30
SWEP.PA_TakeAmmo = 1
SWEP.PA_Delay = .09
SWEP.PA_Recoil = 1
SWEP.PA_Spread = .016
SWEP.PA_AimSpread = .013
SWEP.PA_AimRecoil = .9
SWEP.SA_SightFOV = 65
SWEP.SA_Delay = .1

SWEP.DrawTime = .5
SWEP.StopRAnimTime = 1.5
SWEP.ReloadTime = 1.6
SWEP.ClipoutTime = 0.4
SWEP.ClipinTime = 1.3
SWEP.ReloadTime2 = 2.8
SWEP.BoltPullTime=2.25
SWEP.SightPos = Vector(-6.39, 90, 2.54)
SWEP.SightAng = Angle(0, 0, 0)
SWEP.CenterPos = Vector( 0, 80, 0 )
SWEP.CenterAng = Angle( 0, 0, 0 )
