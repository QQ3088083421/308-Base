if !util.IsValidModel("models/vuthakral/halo/weapons/c_hum_srs99c.mdl")then return end
SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "HALO SRS99C"
SWEP.Category = "308 Hidden Wep"
SWEP.HoldType = "ar2"
SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.PA_Sound = "vuthakral/halo/weapons/srs99c/fire0.wav"
SWEP.PA_SoundDist = "vuthakral/halo/weapons/sniper_dist0.wav"
SWEP.PA_Damage = 76
SWEP.ViewModel = "models/vuthakral/halo/weapons/c_hum_srs99c.mdl"
SWEP.WorldModel = "models/vuthakral/halo/weapons/w_srs99c.mdl"
SWEP.Primary.ClipSize = 4
SWEP.Primary.DefaultClip = 4
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "SniperPenetratedRound"
SWEP.PA_Recoil = 5
SWEP.PA_Spread = .1
SWEP.PA_Delay = .75
SWEP.PA_AimSpread = .00009
SWEP.PA_AimRecoil = 4
SWEP.PA_Range=300
SWEP.BlockPrimary=true

SWEP.PA_VeloS = 500
SWEP.ReloadAnimD2={{Anim="reload_empty"}}
SWEP.DrawAnim = "draw"
SWEP.SA_SightFOV = 12
SWEP.SA_Delay = .5
SWEP.PA_DryFireSound="vuthakral/halo/weapons/m6d/dryfire.wav"
SWEP.SA_SightS="vuthakral/halo/weapons/srs99c/zoom_in.wav"
SWEP.SA_SightS2="vuthakral/halo/weapons/srs99c/zoom_out.wav"
SWEP.DrawCross=false

SWEP.TextIcon="vgui/entities/drchalo_sniper"
SWEP.StopRAnimTime = 2.6
SWEP.NormalDraw = true
SWEP.ReloadTime = 2.7
SWEP.ReloadTime2 = 3.3
SWEP.ClipoutTime = 0.8
SWEP.ClipinTime = 1.9
SWEP.BoltPullTime=2.5

SWEP.CenterPos = Vector(0,0,0)
SWEP.SightPos = Vector(-3.4,250,2.3)
function SWEP:BeforePA()
self.PA_Sound="vuthakral/halo/weapons/srs99c/fire"..math.random(0,3)..".wav"
self.PA_SoundDist="vuthakral/halo/weapons/sniper_dist"..math.random(0,3)..".wav"
end
function SWEP:CusHUD()
x = ScrW()/2
y = ScrH()/2
sw = surface.ScreenWidth()
sh = surface.ScreenHeight()
	if self.Scope==1 then
		surface.SetDrawColor(255,255,255,255)

		surface.DrawLine(x,y+100,x,y-100)
		surface.DrawLine(x+100,y,x-100,y)

		surface.DrawLine(x+30,y+10,x+30,y-10)
		surface.DrawLine(x+60,y+10,x+60,y-10)
		surface.DrawLine(x+10,y+30,x-10,y+30)
		surface.DrawLine(x+10,y+60,x-10,y+60)

		surface.DrawLine(x-30,y+10,x-30,y-10)
		surface.DrawLine(x-60,y+10,x-60,y-10)
		surface.DrawLine(x+10,y-30,x-10,y-30)
		surface.DrawLine(x+10,y-60,x-10,y-60)

		surface.SetDrawColor(0,255,0,15)
		surface.DrawRect(0,0,ScrW(),ScrH())
		surface.SetDrawColor(0,20,0,255)
		surface.DrawRect(0,0,sw,sh/6)
		surface.DrawRect(0,sh-sh/6,sw,sh/3)
		surface.DrawRect(sw-sw/3,0,sw/3,sh)
		surface.DrawRect(0,0,sw/3,sh)
	end
end
function SWEP:ShootAnim()self:PlayAnim("fire")end