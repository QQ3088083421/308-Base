SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName = "P90"
SWEP.Category = "308..' Base"
SWEP.HoldType = "smg"
SWEP.ViewModel = "models/weapons/cstrike/c_smg_p90.mdl"
SWEP.WorldModel = "models/weapons/w_smg_p90.mdl"

SWEP.Primary.ClipSize = 50
SWEP.Primary.DefaultClip = 50
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "smg1"

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.Spawnable = true
SWEP.PA_Sound="weapons/p90/p90-1.wav"
SWEP.PA_Damage = 20
SWEP.PA_Delay = .067
SWEP.PA_Recoil = .65
SWEP.PA_Spread = .01
SWEP.PA_AimSpread = .009
SWEP.PA_AimRecoil = .6
SWEP.SA_SightFOV = 50

SWEP.TextType = "308CS"
SWEP.Text = "m"
SWEP.CustomAmmoIcon ="S"

SWEP.BAnim="draw"
SWEP.SA_Delay = .2
SWEP.SA_Cross = true
SWEP.DrawTime = .5
SWEP.StopRAnimTime = 2.5
SWEP.ReloadTime = 2.6
SWEP.ClipoutTime = 1
SWEP.ClipinTime = 2.15
SWEP.ReloadTime2 = 3.3
SWEP.BoltPullTime=2.7
SWEP.SightPos = Vector(-3,110,2)
SWEP.CenterPos = Vector(-1,80,1)