SWEP.Base = "weapon_308_base" -- Don't touch!if you true to do you better write a base
SWEP.PrintName=GAME308_LANWEP["parachute"]
SWEP.Category = "308..' Base"
SWEP.HoldType = "duel"
SWEP.ViewModel = "models/weapons/shell.mdl"
SWEP.ShowWorldModel=false
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Slot = 1
SWEP.PA_Num=0
SWEP.Spawnable = true
SWEP.SA_IsSight = false

SWEP.AmmoHUD=2
SWEP.DrawTime = 0
SWEP.WElements = {
	["1+"] = { type = "Model", model = "models/hunter/tubes/tube1x1x1.mdl", bone = "ValveBiped.Bip01_R_Clavicle", rel = "", pos = Vector(3.049, 0.69, -0.819), angle = Angle(-90, 0, 0), size = Vector(0.268, 0.194, 0.064), color = Color(55, 55, 55, 255), surpresslightning = false, material = "rubber", skin = 0, bodygroup = {} },
	["1"] = { type = "Model", model = "models/props_c17/FurnitureFridge001a.mdl", bone = "ValveBiped.Bip01_Spine4", rel = "", pos = Vector(-2.02, 2.125, 0), angle = Angle(0, -90, -90), size = Vector(0.221, 0.62, 0.233), color = Color(255, 255, 255, 255), surpresslightning = false, material = "grey", skin = 0, bodygroup = {} },
	["1++"] = { type = "Model", model = "models/hunter/tubes/tube1x1x1.mdl", bone = "ValveBiped.Bip01_L_Clavicle", rel = "", pos = Vector(5.276, 1.506, -0.247), angle = Angle(-90, 0, 0), size = Vector(0.268, 0.194, 0.064), color = Color(55, 55, 55, 255), surpresslightning = false, material = "rubber", skin = 0, bodygroup = {} }
}
SWEP.CenterPos=Vector(0,500,0)
function SWEP:BeforeHolster()return 1 end
function SWEP:OnDrop2()self:StopSound("ambient/wind/wind1.wav")self:Remove()end
function SWEP:Reload()end
if SERVER then

function SWEP:PrimaryAttack()
if self.DrawTime<1 then
self.DrawTime=5
local a=ents.Create("prop_physics")
a:SetModel("models/props_phx/construct/metal_dome360.mdl")
a:SetParent(self)
a:SetSolid(SOLID_NONE)
a:SetMaterial("models/shiny")
a:SetColor(Color(math.random(255),math.random(255),math.random(255)))
a:SetPos(self.Owner:EyePos()+Vector(0,0,20))
a:SetAngles(Angle(0,0,0))
a:SetModelScale(2)
a:Spawn()
self:DeleteOnRemove(a)
self.Owner:EmitSound("ambient/machines/thumper_top.wav",100,150)
end
end
function SWEP:CustomThink()
local p=self.Owner
self:EmitSound("ambient/wind/wind1.wav",100,50)
if p:IsOnGround()then
self:StopSound("ambient/wind/wind1.wav")
p:EmitSound("player/pl_jumpland2.wav")
self:Holster(1)
self:Remove()
elseif self.DrawTime>4 then
p:SetLocalVelocity(p:GetVelocity()*.93)
end
if (p:KeyDown(IN_FORWARD)||p:KeyDown(IN_ATTACK))and p:GetAngles().x>0 then
p:SetVelocity(p:GetForward()*12)
end
end

end