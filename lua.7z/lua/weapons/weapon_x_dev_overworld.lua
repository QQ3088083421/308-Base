
AddCSLuaFile()

SWEP.PrintName = "!RPG Overworld Test"
SWEP.Author = "QQ3088083421"
SWEP.Category = "308..' Base"

SWEP.Slot = 0
SWEP.SlotPos = 4

SWEP.Spawnable = true

SWEP.ViewModel="models/effects/portalfunnel.mdl"
SWEP.WorldModel="models/weapons/w_toolgun.mdl"
SWEP.ShowViewModel=true
SWEP.ShowWorldModel=false
SWEP.ViewModelFOV = 64
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"
SWEP.DrawAmmo=false
SWEP.DrawCrosshair=false

SWEP.Wall={
[1]={x=60,y=60}
}
SWEP.Speed=8
SWEP.SpeedRun=17
--==
SWEP._Speed=4
SWEP._T_Walk=0
--SWEP._B_Walk
--==
function SWEP:Initialize()self:SetHoldType("camera")end
function SWEP:PrimaryAttack()end
function SWEP:SecondaryAttack()end
function SWEP:Reload()end
function SWEP:OnDrop()end
function SWEP:Holster()local p=self.Owner p:SetNWBool("308Overworld",false)p:SetMoveType(2)return true end
function SWEP:Deploy()local p=self.Owner p:SetNWInt("308OW_Y",60)p:SetNWInt("308OW_X",-120)p:SetMoveType(0)end
function SWEP:Think()local p=self.Owner
local m=false
p:SetNWBool("308Overworld",true)self._Speed=self.Speed
if p:KeyDown(IN_SPEED)then
self._Speed=self.SpeedRun
end
--[[
if p:KeyDown(IN_FORWARD)then m=true
p:SetNWInt("308OW_Y",p:GetNWInt("308OW_Y")+self._Speed)p:SetNWInt("308OW_C_ANGLE",4)elseif p:KeyDown(IN_BACK)then
p:SetNWInt("308OW_Y",p:GetNWInt("308OW_Y")-self._Speed)p:SetNWInt("308OW_C_ANGLE",2)m=true end
if p:KeyDown(IN_MOVELEFT)then m=true
p:SetNWInt("308OW_X",p:GetNWInt("308OW_X")+self._Speed)p:SetNWInt("308OW_C_ANGLE",3)elseif p:KeyDown(IN_MOVERIGHT)then
p:SetNWInt("308OW_X",p:GetNWInt("308OW_X")-self._Speed)p:SetNWInt("308OW_C_ANGLE",1)m=true end
--]]
p:SetNWInt("308OW_C_Speed",self._Speed)end
--function SWEP:DrawHUD()end
if SERVER then return end
local v={}v.x=0 v.y=0
--local t={}t[1].
hook.Add("PreDrawHUD","308KillIcon6",function()
cam.Start2D()
local p=LocalPlayer()

CreateClientConVar("ux_ts" , 1 , true , false)
--[[
local ent = FindMetaTable("Entity")
local vec = FindMetaTable("Vector")
if ConVarExists( "ux_ts" ) and GetConVar("ux_ts"):GetInt() == 1 then
         for k , v in pairs (GetAll()) do
         if(!v:Alive()) then continue end
         if(v:IsDormant()) then continue end
         if(v == LocalPlayer()) then continue end
         local Position = (v:GetPos() + Vector(0,0,80)) :ToScreen()
         draw.DrawText(v:Name(), "Default", Position.x, Position.y, Color(255,0,0), 1)
         local hp = v:Health()
         draw.DrawText(hp , "Default" , Position.x , Position.y + 10 , Color(0,255,0), 1)
         local pos = ent.GetPos(v);
         local poss = pos + Vector(0, 0, 70); 
         local pos = vec.ToScreen(pos);         
         local poss = vec.ToScreen(poss);
         local h = pos.y - poss.y;         
         local w = h / 2; 
         local health = math.Clamp(v:Health(), 0, 100)
         surface.SetDrawColor(HSVToColor( health / 100 * 120, 1, 1 ));
         surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
     end
end 
--]]
if !p:GetNWBool("308Overworld")then
local e=p:GetEyeTrace().Entity
if IsValid(e)and e.Is308Bot and e.IsBoss then
local tc=TEXT_ALIGN_CENTER
local h=e:GetNWInt("_HP")
local m=e:GetMaxHealth()
local c=h/m*255
draw.SimpleText(e.KillName or e.PrintName,"308MinecraftFont", ScrW() * .5, ScrH() * .72,Color(255,255,255),tc,tc)
draw.SimpleText("Boss Health:","308MinecraftFont", ScrW() * .5, ScrH() * .76,Color(255,255,255),tc,tc)
draw.SimpleText(h.."/"..e:GetMaxHealth(),"308MinecraftFont", ScrW() * .5, ScrH() * .8,Color(255,c,c),tc,tc)
surface.SetDrawColor(255,0,0,255)
surface.DrawRect(ScrW()*.45,ScrH()*.83,ScrW()*.1,ScrH()*.04)
surface.SetDrawColor(255,255,0,255)
surface.DrawRect(ScrW()*.45,ScrH()*.83,ScrW()*h/m/10,ScrH()*.04)
end
return end
p:SetNWInt("308OW_C_ANGLE",p:GetNWInt("308OW_C_ANGLE2"))
if p:GetNWInt("308OW_Y")<60||p:GetNWInt("308OW_Y2")>-180 then
p:SetNWInt("308OW_Y",p:GetNWInt("308OW_Y2")or p:GetNWInt("308OW_Y"))end
if p:GetNWInt("308OW_X2")<-120||p:GetNWInt("308OW_X2")>-12000 then
p:SetNWInt("308OW_X",p:GetNWInt("308OW_X2")or p:GetNWInt("308OW_X"))end
local m
if p:KeyDown(IN_FORWARD)then m=1
p:SetNWInt("308OW_Y",p:GetNWInt("308OW_Y")+p:GetNWInt("308OW_C_Speed"))p:SetNWInt("308OW_C_ANGLE",4)elseif p:KeyDown(IN_BACK)then
p:SetNWInt("308OW_Y",p:GetNWInt("308OW_Y")-p:GetNWInt("308OW_C_Speed"))p:SetNWInt("308OW_C_ANGLE",2)m=1 end
p:SetNWInt("308OW_Y2",p:GetNWInt("308OW_Y"))
p:SetNWInt("308OW_Y",math.Clamp(p:GetNWInt("308OW_Y"),-180,60))
if p:KeyDown(IN_MOVELEFT)then m=1
p:SetNWInt("308OW_X",p:GetNWInt("308OW_X")+p:GetNWInt("308OW_C_Speed"))p:SetNWInt("308OW_C_ANGLE",3)elseif p:KeyDown(IN_MOVERIGHT)then
p:SetNWInt("308OW_X",p:GetNWInt("308OW_X")-p:GetNWInt("308OW_C_Speed"))p:SetNWInt("308OW_C_ANGLE",1)m=1 end
p:SetNWInt("308OW_X2",p:GetNWInt("308OW_X"))
p:SetNWInt("308OW_X",math.Clamp(p:GetNWInt("308OW_X"),-12000,-120))

p:SetNWBool("308OW_MOVE",m)
if m then
p:SetNWInt("308OW_C_ANGLE2",p:GetNWInt("308OW_C_ANGLE"))
if p:GetNWInt("308OW_C_MTimer")<CurTime()then
if p._B_Walk then
if p:GetNWInt("308OW_C_MOVING")>1 then
p:SetNWInt("308OW_C_MOVING",p:GetNWInt("308OW_C_MOVING")-1)else
p:SetNWInt("308OW_C_MOVING",2)surface.PlaySound("player/footsteps/metal"..math.random(4)..".wav")p._B_Walk=nil end
else
if p:GetNWInt("308OW_C_MOVING")<3 then
p:SetNWInt("308OW_C_MOVING",p:GetNWInt("308OW_C_MOVING")+1)else
p:SetNWInt("308OW_C_MOVING",2)surface.PlaySound("player/footsteps/metal"..math.random(4)..".wav")p._B_Walk=1 end
end
p:SetNWInt("308OW_C_MTimer",CurTime()+1.4/p:GetNWInt("308OW_C_Speed"))
end
else p._B_Walk=nil
p:SetNWInt("308OW_C_MOVING",2)end
surface.SetDrawColor(Color(255,255,255,255))
for i=1,4 do
surface.SetMaterial(Material("skybox/sky_day03_06lf","pixel"))
surface.DrawTexturedRect(ScrW()*(i-2)+p:GetNWInt("308OW_X")/10+30*math.sin(CurTime()*.1),ScrH()-ScrW()+30*math.sin(CurTime()*.2),ScrW()+300,ScrW()+300)end
for i=1,100 do
surface.SetMaterial(Material("3088083421/rpgtest/testwall.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5-60+p:GetNWInt("308OW_X")+120*i,ScrH()*.5-180+p:GetNWInt("308OW_Y"),120,120)

surface.SetMaterial(Material("3088083421/rpgtest/testwall.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5-60+p:GetNWInt("308OW_X")+120*i,ScrH()*.5+300+p:GetNWInt("308OW_Y"),120,120)

surface.SetMaterial(Material("3088083421/rpgtest/testfloor.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5-60+p:GetNWInt("308OW_X")+120*i,ScrH()*.5-60+p:GetNWInt("308OW_Y"),120,120)

surface.SetMaterial(Material("3088083421/rpgtest/testfloor.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5-60+p:GetNWInt("308OW_X")+120*i,ScrH()*.5+60+p:GetNWInt("308OW_Y"),120,120)

surface.SetMaterial(Material("3088083421/rpgtest/testfloor.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5-60+p:GetNWInt("308OW_X")+120*i,ScrH()*.5+180+p:GetNWInt("308OW_Y"),120,120)
end
local a="u"
if p:GetNWInt("308OW_C_ANGLE")==1 then
a="r"
elseif p:GetNWInt("308OW_C_ANGLE")==2 then
a="d"
elseif p:GetNWInt("308OW_C_ANGLE")==3 then
a="l"
end
surface.SetMaterial(Material("3088083421/1.png","smooth"))
surface.DrawTexturedRect(ScrW()*.5+8635+p:GetNWInt("308OW_X"),ScrH()*.5-460+p:GetNWInt("308OW_Y"),600,280)
surface.SetMaterial(Material("3088083421/rpgtest/creator"..a..""..p:GetNWInt("308OW_C_MOVING")..".png","pixel"))
local tc=TEXT_ALIGN_CENTER
draw.SimpleText(p:Nick(),"8bitoperator",ScrW()*.5,ScrH()*.5-60,Color(255,255,255),tc,tc)
surface.DrawTexturedRect(ScrW()*.5-60,ScrH()*.5-60,120,120)

for i=1,41 do
surface.SetMaterial(Material("3088083421/rpgtest/testsprite.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5+180+p:GetNWInt("308OW_X")+600*i,ScrH()*.5+p:GetNWInt("308OW_Y"),120,360)
end
for i=1,41 do
surface.SetMaterial(Material("3088083421/rpgtest/testsprite.png","pixel"))
surface.DrawTexturedRect(ScrW()*.5+180+p:GetNWInt("308OW_X")+600*i,ScrH()*.5-480+p:GetNWInt("308OW_Y"),120,360)
end
cam.End2D()
end)
