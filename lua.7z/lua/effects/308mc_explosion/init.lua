function EFFECT:Init(data)
	local p=data:GetOrigin()
	local g=data:GetMagnitude()or 1
	local c1=math.random(200,255)
	local c2=math.random(200,240)
	local c3=math.random(50,90)
	local m=ParticleEmitter(p)
	local a
	if !MC_NoMissMDL then a="particles/smokey" end
		for i=1,math.floor(175*g)do
			local e=m:Add(a or "particles/minecraft/smoke"..math.random(0,1),p)
			if e then
				e:SetVelocity(VectorRand()*math.Rand(10,1400)*g)
				e:SetLifeTime(0)
				e:SetDieTime(math.Rand(3,4))local s=math.Rand(7,9)*g
				e:SetStartSize(s)
				e:SetEndSize(s)
				e:SetBounce(1)
				e:SetAirResistance(300)
				e:SetGravity(Vector(0,0,100))
				e:SetStartAlpha(255)
				e:SetEndAlpha(255)
				e:SetColor(c1,c1,c1)
				if !a then
				timer.Simple(math.Rand(1.45,2),function()e:SetMaterial("particles/minecraft/smoke0")end)end
			end
			local e3=m:Add(a or "particles/minecraft/smoke5",p)
			if e3 then
				e3:SetVelocity(VectorRand()*math.Rand(800,1000)*g)
				e3:SetLifeTime(0)
				e3:SetDieTime(math.Rand(3.5,5))local s=math.Rand(5,7)*g
				e3:SetStartSize(s)
				e3:SetEndSize(s)
				e3:SetBounce(1) 
				e3:SetAirResistance(400)
				e3:SetGravity(Vector(0,0,100))
				e3:SetStartAlpha(255)
				e3:SetEndAlpha(255)
				e3:SetColor(c2,c2,c2)
				if !a then
				for l=1,5 do
				timer.Simple(l*math.Rand(.5,.75),function()e3:SetMaterial("particles/minecraft/smoke"..5-l)end)end end
			end
		end
		for i=1,math.floor(80*g)do
			local e2=m:Add(a or "particles/minecraft/smoke3",p)
			if e2 then
				e2:SetVelocity(VectorRand()*math.Rand(300,1300)*g)
				e2:SetLifeTime(0)
				e2:SetDieTime(math.Rand(4,5))local s=math.Rand(6,8)*g
				e2:SetStartSize(s)
				e2:SetEndSize(s)
				e2:SetBounce(1)
				e2:SetAirResistance(120)
				e2:SetGravity(Vector(0,0,100))
				e2:SetStartAlpha(255)
				e2:SetEndAlpha(255)
				e2:SetColor(c3,c3,c3)
				if !a then
				for l=1,3 do
				timer.Simple(l*math.Rand(.85,1),function()e2:SetMaterial("particles/minecraft/smoke"..3-l)end)end end
			end
		end
	m:Finish()
end
function EFFECT:Think()return false end
function EFFECT:Render()end
function RandomSpherePoint()
	local azimuthal=2*math.pi*math.random()
	local sin2_zenith=math.random()
	local sin_zenith=math.sqrt(sin2_zenith)
	local zrand=math.random(2)
	if zrand==2 then zrand = -1 else zrand = 1 end
	local final = Vector( sin_zenith*math.cos(azimuthal) , sin_zenith*math.sin(azimuthal) , zrand*math.sqrt(1-sin2_zenith) );
	final:Normalize()
	return final
end
