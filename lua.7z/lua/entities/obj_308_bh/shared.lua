ENT.Type 			= "anim"
ENT.PrintName		= ""
ENT.Spawnable		= false
ENT.AdminSpawnable	= false