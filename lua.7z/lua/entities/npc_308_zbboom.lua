AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["zbboom"]
ENT.Infection="npc_308_freshdead"
ENT.InfectionPM=true
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_ZOMBIES}
ENT.BloodColor=6
ENT.HP=75
ENT.StartSpeed=120
ENT.Color=Color(0,255,0)
ENT.Model="models/zombie/classic.mdl"
ENT.AttRate=2
ENT.IdleAct=ACT_IDLE_ON_FIRE
ENT.MoveAct=ACT_WALK_ON_FIRE
function ENT:Attack()self:Kill()end
function ENT:OnDead(d)local a
if d and IsValid(d:GetAttacker())then a=d:GetAttacker()end
local e=ents.Create("env_explosion")
e:SetOwner(self.boom1)
e:SetPos(self:GetPos())
e:SetKeyValue("iMagnitude", "0")
e:SetKeyValue("spawnflags", "305")
e:Spawn()
e:Activate()
e:Fire("Explode","",0)
local e2=ents.Create("env_physexplosion")
e2:SetOwner(self.boom1)
e2:SetPos(self:GetPos())
e2:SetKeyValue("magnitude","150")
e2:SetKeyValue("radius","300")
e2:SetKeyValue("spawnflags","3")
e2:Spawn()
e2:Activate()
e2:Fire("Explode","",0)
self:EmitSound("3088083421/nanoboom.mp3",511)
self.HasRagdoll="models/Humans/Charple01.mdl"
self:EXPLOAD(100,100,a)
end