ENT.Type 			= "anim"
ENT.PrintName = ""
ENT.Category		= "308..' Base"
ENT.Spawnable		= true
ENT.AdminOnly		= true