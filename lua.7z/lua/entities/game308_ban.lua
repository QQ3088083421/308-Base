AddCSLuaFile()
ENT.Type="anim"
ENT.PrintName=""
function ENT:Draw()end
function ENT:Initialize()if CLIENT then return end
BED308Ent=self
self:SetMoveType(MOVETYPE_NONE)self:SetSolid(SOLID_NONE)
for _,p in pairs(ents.GetAll())do
if p:IsPlayer()then
p:SetAvoidPlayers(true)
p:SetMaterial("")
p:SetColor(color_white)
p:StripAmmo()
p:StripWeapons()
p:GodDisable()
if p:IsAdmin()||p:IsSuperAdmin()then
p:ConCommand("mp_falldamage 1")
p:ConCommand("sv_gravity 600")
p:ConCommand("sv_friction 8")
p:ConCommand("sbox_playershurtplayers 1")
p:ConCommand("sbox_godmode 0")
p:ConCommand("ai_ignoreplayers 0")end
end
local c=p:GetClass()
if p:IsNPC()||IsNextBot3(p)||p:IsWeapon()||p:IsRagdoll()||p:IsVehicle()||p:IsWeapon()||p.__MustRemove||
(IsValid(p:GetCreator())and p:GetCreator():IsPlayer()and !string.find(p:GetClass(),"obj_308_"))then p:Remove()end
end
if GetConVarNumber("skill")!=1 then
RunConsoleCommand("skill","1")end
if GetConVarNumber("sv_gravity")!=600 then
RunConsoleCommand("sv_gravity","600")end
if GetConVarNumber("sv_friction")!=8 then
RunConsoleCommand("sv_friction","8")end
if GetConVarNumber("sbox_playershurtplayers")!=1 then
RunConsoleCommand("sbox_playershurtplayers","1")end
if GetConVarNumber("sbox_godmode")!=0 then
RunConsoleCommand("sbox_godmode","0")end
if GetConVarNumber("ai_ignoreplayers")!=0 then
RunConsoleCommand("ai_ignoreplayers","0")end
if GetConVarNumber("ai_disabled")!=0 then
RunConsoleCommand("ai_disabled","0")end
end
function ENT:OnRemove()if self._Sd then RunConsoleCommand("shrinkinator_scale_damage","1")end
if self._Sm then RunConsoleCommand("shrinkinator_scale_movement","1")end
end
function ENT:Think()local w
if GetConVarNumber("shrinkinator_scale_damage")!=0 then
RunConsoleCommand("shrinkinator_scale_damage","0")w=1 self._Sd=1 end
if GetConVarNumber("shrinkinator_scale_movement")!=0 then
RunConsoleCommand("shrinkinator_scale_movement","0")w=1 self._Sm=1 end
if w then 
for _,p in pairs(player.GetAll())do
if self._S then
p:ConCommand("say stopg")p:ChatPrint(" \n \n \n \n \n \n \n \nFine you wanna to close the game right?")else
p:ChatPrint("Sorry but i must disable it if you want to play minigames!\ni will re-enable it when the minigame end!")end
end
if SERVER and self._S then
SafeRemoveEntity(self)end
self._S=1
end
if GetConVarNumber("sv_gravity")!=600 then
RunConsoleCommand("sv_gravity","600")end
if GetConVarNumber("sv_friction")!=8 then
RunConsoleCommand("sv_friction","8")end
if GetConVarNumber("sbox_playershurtplayers")!=1 then
RunConsoleCommand("sbox_playershurtplayers","1")end
if GetConVarNumber("sbox_godmode")!=0 then
RunConsoleCommand("sbox_godmode","0")end
if GetConVarNumber("ai_ignoreplayers")!=0 then
RunConsoleCommand("ai_ignoreplayers","0")end
end
