ENT.Type 			= "anim"
ENT.PrintName="Zombie Survival"
if GAME308_LANMath==2 then
ENT.PrintName="僵尸生存"
end
ENT.Category		= "308..' Base"
ENT.Spawnable		= true
ENT.AdminOnly		= true