AddCSLuaFile()
ENT.Base = "npc_308_zbstr"
ENT.PrintName="Zombie Tank"
if GAME308_LANMath==2 then
ENT.PrintName="僵尸坦克"
end
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Scale=2
ENT.HP=4350
ENT.Color=Color(255,215,150)
ENT.Acceleration=200
ENT.StartSpeed=150
ENT.AttRate=1.5
ENT.AttRange=40
ENT.Att={{Range=55,dmg=55,Time=.7,SHit="physics/body/body_medium_break3.wav",SMiss="WeaponFrag.Throw"}}
ENT.STi=0
ENT.ST=1
function ENT:CustomThink()
if self:HasEnemy()then
if self.STi<CurTime()and self.ST then
self.Acceleration=800
self:EmitSound("npc/zombie_poison/pz_throw"..math.random(2,3)..".wav",400,90)
timer.Simple(1,function()if IsValid(self)then
self.Acceleration=200
end end)
self.ST=nil
self.STi=CurTime()+3
self.Speed=800
self:SetSpeed(800)
self.AttRate=4
self.Att={{Range=100,dmg=40,Time=.25,SHit="physics/body/body_medium_break3.wav",SMiss="WeaponFrag.Throw"}}elseif self.STi<CurTime()and !self.ST then
self:EmitSound("npc/zombie_poison/pz_warn2.wav",400,90)
self.AttRate=1.5
self.Att={{Range=55,dmg=35,Time=.7,SHit="physics/body/body_medium_break3.wav",SMiss="WeaponFrag.Throw"}}
self.ST=1
self.STi=CurTime()+8
self.Speed=150
self:SetSpeed(150)
end
end
end
function ENT:OnAttack()
self.Acceleration=200
self.AttRate=1.5
self.Att={{Range=55,dmg=35,Time=.7,SHit="physics/body/body_medium_break3.wav",SMiss="WeaponFrag.Throw"}}
self.ST=1
self.STi=CurTime()+8
self.Speed=150
self:SetSpeed(150)
end
function ENT:CustomInit()local v=Vector(1.5,1.5,1.5)self:DrawShadow()
self:ManipulateBonePosition(8,Vector(9,0,0))
self:ManipulateBonePosition(18,Vector(0,0,9))
self:ManipulateBoneScale(6,v)
self:ManipulateBoneScale(7,v)
self:ManipulateBoneScale(8,v)
self:ManipulateBoneScale(9,v)
self:ManipulateBoneScale(10,v)
self:ManipulateBoneScale(15,v)
self:ManipulateBoneScale(16,v)
self:ManipulateBoneScale(17,v)
self:ManipulateBoneScale(18,v)
self:ManipulateBoneScale(19,v)
end
function ENT:OnHurt()local v=Vector(1.5,1.5,1.5)
self:EmitSound("3088083421/zb/zh"..math.random(2)..".wav")
end
function ENT:OnDead()
self:EmitSound("3088083421/zb/zd"..math.random(2)..".wav")
end