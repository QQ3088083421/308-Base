ENT.Type 			= "anim"
ENT.PrintName=GAME308_LAN1["ca"].."I"
ENT.Category		= "308..' Base"
ENT.Spawnable		= true
ENT.AdminOnly		= true