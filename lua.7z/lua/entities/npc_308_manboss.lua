AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["manboss"]
if game.SinglePlayer()then ENT.Spawnable=true end
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.IsBoss=true
ENT.HP=4500
ENT.AttRange=30
ENT.Scale=1.1
ENT.Color=Color(255,115,9)
ENT.StartSpeed=270
ENT.AttRate=2
ENT.AttRange=52
ENT.QuickRemove=1
ENT.Att={{Range=58,Time=.2,dmg=16,SHit="Flesh.ImpactHard",SMiss="WeaponFrag.Throw"}}
ENT.SQuestion=_308BotNQuestion
ENT.SAnswer=_308BotNAnswer
function ENT:CustomInit()
local e=ents.Create("prop_physics")
e:SetModel("models/weapons/w_spade.mdl")e:SetMaterial("models/props_combine/portalball001_sheet")
e:SetPos(self:GetPos()+Vector(0,0,35)+self:GetRight()*3.9+self:GetForward()*42)
e:SetAngles(self:GetAngles()+Angle(-90,0,10))
e:Spawn()e:SetMoveType(0)e:SetSolid(0)
e:SetParent(self,5)
self.S=ents.Create("prop_physics")self.S:SetMaterial("models/props_combine/com_shield001a")
self.S:SetModel("models/props_phx/construct/glass/glass_plate1x1.mdl")
self.S:SetPos(self:GetPos()+Vector(0,0,33)+self:GetRight()*-10+self:GetForward()*14)
self.S:SetAngles(self:GetAngles()+Angle(-10,0,-150))self.S:Spawn()self.S:SetMoveType(0)self.S:SetCollisionGroup(4)self.S:SetHealth(500)self.S:SetParent(self,6)
_308PlaySoundAll("ambient/levels/prison/inside_battle_soldier1.wav",50)
_308PlaySoundAll("hl1/ambience/port_suckin1.wav",90)
end
function ENT:OnTakeDamage(d)self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav",100,90)end