ENT.Type 			= "anim"
ENT.PrintName		= "C4 Point"
ENT.Category		= "308..' Base"
ENT.Spawnable		= true
ENT.AdminOnly		= true