AddCSLuaFile()
ENT.Base="npc_308_solider"
ENT.PrintName=GAME308_LANWEP["solider"].."(AK47)"
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.HP=60
ENT.Ammo=30
ENT.Color=Color(255,0,0)
ENT.StartSpeed=140
ENT.Material="models/props_c17/paper01"
ENT.AttRange=450
ENT.MoveAct=ACT_RUN
ENT.Weapon="308_wm_ak"
--AK47 Guy
function ENT:Attack()
if self.Ammo<1 then
self:SEQ("reload",.6)
self:SoundSlot({{Sound="weapons/ak47/ak47_clipout.wav"},{Sound="weapons/ak47/ak47_clipin.wav",Delay=.8},{Sound="weapons/ak47/ak47_boltpull.wav",Delay=1.5}})
self.Timer=CurTime()+1.8
self.Ammo=30
return end
self.Ammo=self.Ammo-1
self:SoundSlot({{Sound="weapons/ak47/ak47-1.wav",Volume=511,Pitch=90+math.random(0,20)}})
self:SEQ("shootgun2",.5)
self.Timer=CurTime()+.1
self:FireB()
end
function ENT:OnLastEnemy()
if self.Ammo<30 then
self:SEQ("reload",.8)
self:SoundSlot({{Sound="weapons/ak47/ak47_clipout.wav"},{Sound="weapons/ak47/ak47_clipin.wav",Delay=.8}})
self.Timer=CurTime()+1
self.Ammo=31
end end
