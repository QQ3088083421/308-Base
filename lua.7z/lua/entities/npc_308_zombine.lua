AddCSLuaFile()
ENT.Base = "npc_308_zb"
ENT.PrintName="Zombine"
if GAME308_LANMath==2 then
ENT.PrintName="联合军僵尸"
end
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_ZOMBIES}
ENT.HP=100
ENT.StartSpeed=80
ENT.Model="models/zombie/classic.mdl"
ENT.AttSeq2={"swatrightmid","swatleftmid"}
ENT.AttRate=2
ENT.MoveAct=ACT_WALK
ENT.HasRagdoll="models/player/zombie_soldier.mdl"
function ENT:CustomInit()self:DrawShadow()self.Body=self:CreateDynamicMDL("models/player/zombie_soldier.mdl")end
function ENT:OnAttack()if math.random(2)==1 then self.AttSeq="swatleftmid" else self.AttSeq="swatrightmid" end end
function ENT:OnHurt(d)self:EmitSound("npc/zombie/zombie_pain"..math.random(6)..".wav",95)end
function ENT:OnDead()self:EmitSound("npc/zombie/zombie_die"..math.random(3)..".wav",95)SafeRemoveEntity(self.Body)end
ENT.Att={{Range=32,dmg=12,Time=.16,SHit="npc/zombie/claw_strike1.wav"}}
