AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["wafire"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.Color=Color(255,128,0)
ENT.StartSpeed=115
ENT.AttRate=2
ENT.AttRange=30
ENT.HP=250
ENT.QuickRemove=1
ENT.Att={{Range=35,Time=.2,dmg=12,SHit="weapons/crossbow/bolt_skewer1.wav",SMiss="weapons/iceaxe/iceaxe_swing1.wav"}}
ENT.MoveAct=ACT_WALK
ENT.Weapon="weapon_308_axe"
ENT.IgnoreFire=0
function ENT:CustomInit()
local e2=ents.Create("prop_physics")e2:Ignite(9999)
e2:SetModel("models/hunter/blocks/cube025x025x025.mdl")
e2:SetPos(self:GetPos()+Vector(0,0,67)+self:GetForward()*2.9)
e2:SetAngles(self:GetAngles()+Angle(-90,0,10))
e2:Spawn()e2:SetMoveType(0)e2:SetCollisionGroup(6)e2:SetColor(Color(255,128,0))
e2:SetParent(self,1)
if IsValid(self:GetActiveWeapon())then
self:GetActiveWeapon():Ignite(9999)
end
end
function ENT:OnHitEnemy(v)v:Ignite(5)end
function ENT:OnTakeDamage(d)self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav",511,110)end