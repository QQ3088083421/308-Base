AddCSLuaFile()
ENT.Base = "npc_308_zb"
ENT.PrintName=GAME308_LANWEP["zbfast"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Color=Color(199,199,99)
ENT.StartSpeed=120
ENT.Att={{Range=55,dmg=6,Time=.15,SHit="npc/zombie/claw_strike1.wav"}}
