AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["zbheadless"]
ENT.Infection="npc_308_freshdead"
ENT.InfectionPM=true
ENT.BBox=Vector(10,10,45)
ENT.BloodColor=5
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_ZOMBIES}
ENT.HP=50
ENT.StartSpeed=50
ENT.Model="models/Zombie/Fast.mdl"
ENT.AttSeq="melee"
ENT.MoveAct=ACT_WALK
function ENT:CustomInit()
self:ManipulateBoneScale(self:LookupBone("ValveBiped.Bip01_Head1"), Vector(.1,.1,.1))
end
function ENT:OnTakeDamage(d,h)
if h==1 then d:SetDamage(d:GetDamage()/2)end
self:EmitSound("3088083421/zb/zh"..math.random(2)..".wav")
end
ENT.Att={{Range=27,dmg=4,Time=.1,SHit="npc/zombie/claw_strike1.wav"},{Range=27,dmg=4,Time=.4,SHit="npc/zombie/claw_strike2.wav"}}