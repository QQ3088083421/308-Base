AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["target"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.BloodColor=3
ENT.HP=100
ENT.StartAI=false
ENT.NoChase=true
ENT.IdleAct=ACT_WALK
ENT.Model="models/Humans/Group01/male_07.mdl"
ENT.Material="models/props_wasteland/wood_fence01a"
function ENT:Attack()end
function ENT:Use(a)if a:IsPlayer()then
if !self.Kable then
a:PrintMessage(4,"Unkillable")self:SetMaterial("phoenix_storms/metalfloor_2-3")self.Kable=1 else
a:PrintMessage(4,"Killable")self:SetMaterial("models/props_wasteland/wood_fence01a")self.Kable=nil
end end
end
function ENT:OnTakeDamage(d,h)
local a=d:GetAttacker()
if h==1 then h=h.."-Head" elseif h==2 then h="2-Chest" elseif h==3 then h="3-Stomach" elseif h==4 then h="4-Left Arm" elseif h==5 then h=h.."-Right Arm" elseif h==6 then h=h.."-Left Leg" elseif h==7 then h=h.."-Right Leg" end
if !h then h="none or whole" end
if IsValid(a)and a:IsPlayer()then
a:ChatPrint(" \n \n \n ")a:ChatPrint("Stat\nDamage Type:"..d:GetDamageType().."\nDamage:"..d:GetDamage().."\nHit group:"..h)end
if self.Kable then d:SetDamage(0)end
end
function ENT:OnHurt(d)self:EmitSound("3088083421/pl/bhit_flesh-"..math.random(3)..".wav",511)end
function ENT:OnDead()self:EmitSound("3088083421/pl/die"..math.random(3)..".wav",511)end