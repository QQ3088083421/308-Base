ENT.Type 			= "anim"
ENT.PrintName=GAME308_LAN1["gt6"]
ENT.Category		= "308..' Base"
ENT.Spawnable		= true
ENT.AdminOnly		= true