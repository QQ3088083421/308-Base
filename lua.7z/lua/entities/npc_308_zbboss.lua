AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["zbboss"]
if game.SinglePlayer()then ENT.Spawnable=true end
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_ZOMBIES}
ENT.Infection="npc_308_freshdead"
ENT.InfectionPM=true
ENT.Color=Color(255,0,0)
ENT.IsBoss=true
ENT.BloodColor=5
ENT.HP=5000
ENT.Scale=1.2
ENT.Material="models/spawn_effect2"
ENT.StartSpeed=80
ENT.Model="models/zombie/classic.mdl"
ENT.AttSeq2={"swatrightmid","swatleftmid"}
ENT.AttRate=3
ENT.MoveAct=ACT_WALK
function ENT:CustomInit()self:SetBodygroup(1,1)
self.T=CurTime()+10
_308PlaySoundAll("ambient/levels/prison/inside_battle_zombie2.wav",50)
_308PlaySoundAll("hl1/ambience/port_suckin1.wav",90)
end
function ENT:CustomThink()
if self.T<CurTime()and self:HasEnemy()then
self.T=CurTime()+30
_308PlaySoundAll("ambient/creatures/town_zombie_call1.wav")
local e=ents.Create("npc_308_zbminiboss")
e:SetPos(self:GetPos())
e:SetAngles(self:GetAngles())
e:Spawn()
e:SetSpawnEffect(true)
self:DeleteOnRemove(e)
self:SEQ("releasecrab",.5)
end
end
function ENT:OnHurt(d)local h=80+180*(1-self:Health()/self.HP)
self:EmitSound("npc/zombie/zombie_pain"..math.random(6)..".wav",100,80)self:SetSpeed(h)self.Speed=h end
function ENT:OnDead()self:EmitSound("3088083421/zb/zd"..math.random(2)..".wav",100,70)end
ENT.Att={{Range=35,dmg=25,Time=.13,SHit="npc/ichthyosaur/snap.wav"}}