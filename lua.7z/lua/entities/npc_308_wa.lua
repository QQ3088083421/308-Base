AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["wa"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.Color=Color(119,249,249)
ENT.StartSpeed=175
ENT.AttRate=2
ENT.AttRange=30
ENT.Att={{Range=35,Time=.2,dmg=12,SHit="physics/metal/metal_canister_impact_hard3.wav",SMiss="weapons/iceaxe/iceaxe_swing1.wav"}}
ENT.Weapon={"weapon_308_axe","weapon_308_sledgehammer"}
ENT.QuickRemove=1
function ENT:CustomInit()
if self:HasWeapon("weapon_308_axe")then
self.Att={{Range=35,Time=.2,dmg=12,SHit="weapons/crossbow/bolt_skewer1.wav",SMiss="weapons/iceaxe/iceaxe_swing1.wav"}}
end
local e2=ents.Create("prop_physics")
e2:SetModel("models/hunter/blocks/cube025x025x025.mdl")
e2:SetPos(self:GetPos()+Vector(0,0,67)+self:GetForward()*2.9)
e2:SetAngles(self:GetAngles()+Angle(-90,0,10))
e2:Spawn()e2:SetMoveType(0)e2:SetCollisionGroup(6)e2:SetColor(Color(119,249,249))
e2:SetParent(self,1)
end
function ENT:OnTakeDamage(d)self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav",511,90)end