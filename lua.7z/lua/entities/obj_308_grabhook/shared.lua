ENT.Type="anim"
ENT.PrintName="Grab hook"