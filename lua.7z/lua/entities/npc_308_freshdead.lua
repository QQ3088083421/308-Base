AddCSLuaFile()
ENT.Base = "npc_308_zb"
ENT.PrintName="Fresh Dead"
if GAME308_LANMath==2 then
ENT.PrintName="尸体"
end
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_ZOMBIES}
ENT.HP=100
ENT.StartSpeed=100
ENT.Model="models/zombie/classic.mdl"
ENT.AttSeq2={"swatrightmid","swatleftmid"}
ENT.AttRate=2
ENT.MoveAct=ACT_WALK
ENT.Color=Color(200,255,200)
ENT.SIdle2={
"nazi/nz/amb1.mp3",
"nazi/nz/amb2.mp3",
"nazi/nz/amb3.mp3",
"nazi/nz/amb4.mp3",
}
ENT.SCombat2=ENT.SIdle2
ENT.SFoundEnemy2=ENT.SCombat2
function ENT:CustomInit()local t={}
if self._IModel then
t=self._IModel
self:SEQ("slumprise_b",.5)self:EmitSound("3088083421/manif"..math.random(2)..".wav",100,math.random(75,90))
elseif GetConVarNumber("wb3_n_mode")==2 and IsValid(self:GetCreator())then
local p=self:GetCreator()
t={p:GetModel()}self:SetMaterial(p:GetMaterial())self:SetColor(p:GetColor())self:SetSkin(p:GetSkin())self._IBg=p:GetBodyGroups()
else
self:SetPlayerColor(VectorRand())
local c=table.Count(player_manager.AllValidModels())
for i=1,c do
local model=table.Random(player_manager.AllValidModels())
table.insert(t,model)
end
end
if self._IModel||table.Count(t)>0 then
t=_308Table(t)self:SetNoDraw(true)
self.Body=self:CreateDynamicMDL(t)
self.Body:SetMaterial(self:GetMaterial())self:SetSkin(self:GetSkin())
if self._IModel then
if self._IBg then
for k,b in pairs(self._IBg)do
self.Body:SetBodygroup(b.id,self:GetBodygroup(b.id))end end
self.Body:SetColor(self:GetColor())
else
self.Color=Color(200,255,200)
end
self.HasRagdoll=t end
end
function ENT:OnAttack()self:EmitSound("nazi/nz/att_0"..math.random(5)..".mp3")if math.random(2)==1 then self.AttSeq="swatleftmid" else self.AttSeq="swatrightmid" end end
function ENT:OnHurt(d)self:EmitSound("npc/zombie/zombie_pain"..math.random(6)..".wav",120,110)end
function ENT:OnDead()self:EmitSound("nazi/nz/die_0"..math.random(5)..".mp3",120)SafeRemoveEntity(self.Body)self:SetNoDraw()end
ENT.Att={{Range=30,dmg=8,Time=.16,SHit="npc/zombie/claw_strike1.wav"}}
