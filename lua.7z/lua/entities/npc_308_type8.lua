AddCSLuaFile()
ENT.Base = "npc_308_zb"
ENT.PrintName="Type 8"
ENT.Infection="npc_308_freshdead"
ENT.InfectionPM=true
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.BBox=Vector(14,14,72)
ENT.HP=850
ENT.StartSpeed=80
ENT.Model="models/zombie/classic.mdl"
ENT.HasRagdoll="models/Humans/Charple04.mdl"
ENT.AttSeq2={"swatrightmid","swatleftmid"}
ENT.AttRate=2
ENT.MoveAct=ACT_WALK
ENT.CheHP=70
ENT.ArmRHP=10
ENT.ArmLHP=10
ENT.LegRHP=10
ENT.LegLHP=10
function ENT:CustomInit()self:SetNoDraw(true)self:DrawShadow()
self.Body=self:CreateDynamicMDL("models/Humans/Group01/Male_Cheaple.mdl")end
function ENT:OnAttack()if math.random(2)==1 then self.AttSeq="swatleftmid" else self.AttSeq="swatrightmid" end end
function ENT:OnHurt(d,t)
self:EmitSound("physics/flesh/flesh_impact_bullet"..math.random(5)..".wav")
if !IsValid(self.Body)then return end
local dm=d:GetDamage()
local h=self.ArmLHP
if self:Health()<500 and IsValid(self.Body)and !self.D then self.D=1
self:SetHealth(800)local i=0
self.Att={{Range=35,dmg=15,Time=.16,SHit="npc/zombie/claw_strike1.wav"},{Range=35,dmg=10,Time=.16,Type=DMG_POISON,SHit="npc/zombie/claw_strike1.wav"},{Range=35,dmg=5,Time=.16,Type=DMG_BURN}}
while i<self:GetBoneCount()do
if i!=9 and i!=10 and i!=11 and i!=12 then
self:ManipulateBoneJiggle(i,1)
end
i=i+1
end
d=EffectData()d:SetOrigin(self:EyePos())util.Effect("AntlionGib",d)
self:EmitSound("physics/body/body_medium_break3.wav")
self:EmitSound("npc/zombie/zombie_die"..math.random(3)..".wav",150,150)
self.Body:SetModel("models/player/corpse1.mdl")
self.ArmRHP=20
self.ArmLHP=20
self.LegRHP=20
self.LegLHP=20
local v=Vector(1,1,1)
self:ManipulateBoneScale(1,v)
self:ManipulateBoneScale(2,v)
self:ManipulateBoneScale(4,v)
self:ManipulateBoneScale(5,v)
self:ManipulateBoneScale(6,v)
self:ManipulateBoneScale(8,v)
self:ManipulateBoneScale(13,v)
self:ManipulateBoneScale(14,v)
self:ManipulateBoneScale(15,v)
self:ManipulateBoneScale(16,v)
self:ManipulateBoneScale(17,v)
self:ManipulateBoneScale(25,v)
self:ManipulateBoneScale(26,v)
self:ManipulateBoneScale(27,v)
self:ManipulateBoneScale(28,v)
self:ManipulateBoneScale(29,v)
end
if t==4 then
if h>0 then
if h-dm>0 then
self.ArmLHP=h-dm elseif self.ArmLHP>0 then self.ArmLHP=0
d=EffectData()d:SetOrigin(self:EyePos())util.Effect("AntlionGib",d)
self:EmitSound("physics/flesh/flesh_bloody_break.wav")
self:ManipulateBoneScale(13,Vector(.01,.01,.01))
self:ManipulateBoneScale(14,Vector(.01,.01,.01))
self:ManipulateBoneScale(15,Vector(.01,.01,.01))
self:ManipulateBoneScale(16,Vector(.01,.01,.01))
self:ManipulateBoneScale(17,Vector(.01,.01,.01))end
else
d:SetDamage(0)
end
elseif t==7 then
h=self.LegRHP
if h>0 then
if h-dm>0 then
self.LegRHP=h-dm elseif self.LegRHP>0 then self.LegRHP=0
d=EffectData()d:SetOrigin(self:WorldSpaceCenter())util.Effect("AntlionGib",d)
self:EmitSound("physics/flesh/flesh_bloody_break.wav")
local v=Vector(.4,.4,.4)
self:ManipulateBoneScale(5,v)
self:ManipulateBoneScale(6,v)
self:ManipulateBoneScale(8,v)end
end
elseif t==6 then
h=self.LegLHP
if h>0 then
if h-dm>0 then
self.LegLHP=h-dm elseif self.LegLHP>0 then self.LegLHP=0
d=EffectData()d:SetOrigin(self:WorldSpaceCenter())util.Effect("AntlionGib",d)
self:EmitSound("physics/flesh/flesh_bloody_break.wav")
local v=Vector(.4,.4,.4)
self:ManipulateBoneScale(1,v)
self:ManipulateBoneScale(2,v)
self:ManipulateBoneScale(4,v)end
end
elseif t==2 then
h=self.CheHP
if h>0 then
if h-dm>0 then
self.CheHP=h-dm elseif self.CheHP>0 then self.CheHP=0
d=EffectData()d:SetOrigin(self:EyePos())util.Effect("AntlionGib",d)
self:EmitSound("physics/flesh/flesh_bloody_break.wav")
--MsgAll(self:LookupBone("ValveBiped.Bip01_Spine4"))
self:ManipulateBoneScale(9,Vector(.4,.4,.4))end
end
elseif t==5 then
h=self.ArmRHP
if h>0 then
if h-dm>0 then
self.ArmRHP=h-dm elseif self.ArmRHP>0 then self.ArmRHP=0
d=EffectData()d:SetOrigin(self:EyePos())util.Effect("AntlionGib",d)
self:EmitSound("physics/flesh/flesh_bloody_break.wav")
self:ManipulateBoneScale(25,Vector(.01,.01,.01))
self:ManipulateBoneScale(26,Vector(.01,.01,.01))
self:ManipulateBoneScale(27,Vector(.01,.01,.01))
self:ManipulateBoneScale(28,Vector(.01,.01,.01))
self:ManipulateBoneScale(29,Vector(.01,.01,.01))end
else
d:SetDamage(0)
end
end
end
function ENT:OnDead()self:EmitSound("npc/zombie_poison/pz_die"..math.random(2)..".wav",150,90)for i=1,5 do sound.Play("physics/flesh/flesh_bloody_break.wav",self:EyePos(),120,90+10*math.random(5))SafeRemoveEntity(self.Body)local d=EffectData()d:SetOrigin(self:WorldSpaceCenter()+VectorRand()*20)util.Effect("AntlionGib",d)end end
ENT.Att={{Range=35,dmg=15,Time=.16,SHit="npc/zombie/claw_strike1.wav"},{Range=35,dmg=5,Time=.16,Type=DMG_POISON,SHit="npc/zombie/claw_strike1.wav"}}
