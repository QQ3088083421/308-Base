AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["shield"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.HP=80
ENT.Color=Color(255,199,199)
ENT.StartSpeed=250
ENT.AttRate=2
ENT.Att={{Time=.2,dmg=6,SHit="Flesh.ImpactHard",SMiss="WeaponFrag.Throw"}}
ENT.QuickRemove=1
ENT.SQuestion=_308BotNQuestion
ENT.SAnswer=_308BotNAnswer
function ENT:OnTakeDamage()self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav")end
function ENT:CustomInit()
self.S=ents.Create("prop_physics")
self.S:SetModel("models/props_phx/construct/glass/glass_plate1x1.mdl")
self.S:SetPos(self:GetPos()+Vector(0,0,22)+self:GetRight()*11+self:GetForward()*20)
self.S:SetAngles(self:GetAngles()+Angle(-10,0,-50))self.S:Spawn()self.S:SetMoveType(0)self.S:SetCollisionGroup(4)self.S:SetHealth(400)self.S:SetParent(self,5)end
function ENT:OnDead()if IsValid(self.S)then self.S:TakeDamage(100)end end