AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["zbgiant"]
ENT.Infection="npc_308_freshdead"
ENT.InfectionPM=true
ENT.BloodColor=5
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_ZOMBIES}
ENT.HP=400
ENT.Scale=1.5
ENT.StartSpeed=70
ENT.Model="models/zombie/classic.mdl"
ENT.AttSeq2={"swatrightmid","swatleftmid"}
ENT.MoveAct=ACT_WALK
function ENT:OnHurt(d)self:EmitSound("npc/zombie/zombie_pain"..math.random(6)..".wav",100,90)end
function ENT:OnDead()self:EmitSound("npc/zombie/zombie_die"..math.random(3)..".wav",100,90)end
function ENT:CustomThink()if self:IsOnFire()then
self.IdleAct=ACT_IDLE_ON_FIRE
self.MoveAct=ACT_WALK_ON_FIRE
else
self.IdleAct=ACT_IDLE
self.MoveAct=ACT_WALK
end
end
ENT.Att={{Range=30,dmg=10,Time=.2,SHit="npc/zombie/claw_strike1.wav"}}