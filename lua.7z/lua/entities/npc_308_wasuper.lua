AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["wasuper"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.Color=Color(255,0,0)
ENT.StartSpeed=90
ENT.AttRange=40
ENT.HP=250
ENT.AttRate=1.5
ENT.AttTime=.45
ENT.QuickRemove=1
ENT.Att={{Range=49,Time=.3,dmg=15,SHit="physics/flesh/flesh_bloody_break.wav",SMiss="weapons/iceaxe/iceaxe_swing1.wav"}}
ENT.MoveAct=ACT_WALK
function ENT:CustomInit()
local e=ents.Create("prop_physics")
e:SetModel("models/weapons/w_spade.mdl")e:SetModelScale(2)
e:SetPos(self:GetPos()+Vector(0,0,31)+self:GetRight()*-7.1+self:GetForward()*99)
e:SetAngles(self:GetAngles()+Angle(-90,0,10))
e:Spawn()e:SetMoveType(0)e:SetSolid(0)e:SetColor(Color(255,0,0))
e:SetParent(self,5)
local e2=ents.Create("prop_physics")
e2:SetModel("models/hunter/blocks/cube025x025x025.mdl")e2:SetModelScale(1.2)
e2:SetPos(self:GetPos()+Vector(0,0,67)+self:GetForward()*2.9)
e2:SetAngles(self:GetAngles()+Angle(-90,0,10))
e2:Spawn()e2:SetMoveType(0)e2:SetCollisionGroup(6)e2:SetColor(Color(255,0,0))
e2:SetParent(self,1)
end
function ENT:OnTakeDamage(d)self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav",511,110)end