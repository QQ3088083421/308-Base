AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName="Aeolian Body"
if GAME308_LANMath==2 then
ENT.PrintName="疾风体"
end
ENT.Infection="npc_308_freshdead"
ENT.InfectionPM=true
ENT.Spawnable = true
ENT.Acceleration=900
ENT.Deceleration=100
ENT.Category = "308..' NPC"
ENT.HP=200
ENT.Scale=1.2
ENT.Color=Color(199,199,99)
ENT.StartSpeed=220
ENT.BBox=Vector(12,12,65)
ENT.BloodColor=5
ENT.Factions={FACTION_ZOMBIES}
ENT.Spawnable = true
ENT.Model="models/Zombie/Fast.mdl"
ENT.AttSeq="melee"
ENT.MoveAct=ACT_RUN
function ENT:OnHurt(d)self:EmitSound("3088083421/zb/zh"..math.random(2)..".wav",110,110)end
function ENT:OnDead()self:EmitSound("3088083421/zb/zd"..math.random(2)..".wav",110,110)end
ENT.Att={{Range=55,dmg=4,Time=.1,SHit="npc/zombie/claw_strike1.wav"},{Range=55,dmg=4,Time=.4,SHit="npc/zombie/claw_strike2.wav",SMiss="npc/zombie/claw_miss1.wav"}}