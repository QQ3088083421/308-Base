AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["manstr"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.HP=150
ENT.Color=Color(255,199,199)
ENT.StartSpeed=250
ENT.AttRate=2
ENT.Att={{Range=30,Time=.2,SHit="Flesh.ImpactHard",SMiss="WeaponFrag.Throw"}}
function ENT:OnTakeDamage()self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav")end