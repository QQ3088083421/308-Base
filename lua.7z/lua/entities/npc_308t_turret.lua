AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName="Turret"
if GAME308_LANMath==2 then
ENT.PrintName="炮塔" end
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.BloodColor=6
ENT.HP=125
ENT.StartSpeed=40
ENT.Color=Color(199,255,199)
ENT.Model="models/zombie/classic.mdl"
ENT.AttRate=2
ENT.AttRange=0
ENT.AttRange2=400
ENT.MoveAct=ACT_WALK
function ENT:RangeAtt()self.Timer=CurTime()+1.2
for i=1,5 do
local e=ents.Create("grenade_spit")
e:SetAngles(Angle(math.random(360),math.random(360),math.random(360)))e:SetPos(self:EyePos())
e:SetOwner(self)e:Spawn()e:SetModelScale(math.Rand(.5,1.5))
e:SetVelocity((self:GetEnemy():EyePos()-self:GetPos())*1.5+VectorRand()*self:GetRangeTo(self:GetEnemy())/5+Vector(0,0,self:GetRangeTo(self:GetEnemy())/20))
self:EmitSound("physics/body/body_medium_break4.wav")end
end