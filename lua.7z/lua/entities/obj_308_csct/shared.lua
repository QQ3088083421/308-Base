ENT.Type 			= "anim"
ENT.PrintName		= "CT Spawn point"
ENT.Category		= "308..' Base"
ENT.Spawnable		= true
ENT.AdminOnly		= true