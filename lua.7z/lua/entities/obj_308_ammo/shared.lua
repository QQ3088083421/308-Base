ENT.Type 			= "anim"
ENT.PrintName=GAME308_LAN1["ammo"]
ENT.Category		= "308..' Base"
ENT.Spawnable		= true