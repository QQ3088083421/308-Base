AddCSLuaFile()
ENT.Base="npc_308_base_s"
ENT.PrintName=GAME308_LANWEP["sk_kn"]
ENT.Category="308..' NPC"
ENT.Spawnable=true
ENT.AdminOnly=true
--ENT.NoChase=true
ENT.Factions={FACTION_REBELS}
ENT.BBox=Vector(20,20,68)
ENT.HP=300
ENT.QuickRemove=true
ENT.AttackIgnoreWorld=true
ENT.SpriteScale=90
ENT.Sprite="3088083421/kn1s.png"
ENT.SprTogT=CurTime()
ENT.AttRange=1500
ENT.Spr=1
function ENT:OnTakeDamage()
self:EmitSound("3088083421/soulknight/hurt.mp3",511)
end
function ENT:CustomThink()
if self.SprTogT<CurTime()then
self.SprTogT=CurTime()+.4
if self.Spr<2 then
self.Spr=2 else self.Spr=1
end
self:SetSprite("3088083421/kn"..self.Spr.."s.png")end
end
function ENT:Attack()
self.SprTogT=CurTime()+.35
self.Timer=CurTime()+1.5
self:SetSprite("3088083421/knsa1.png")
timer.Simple(.2,function()if IsValid(self)and IsValid(self:GetEnemy())then
self:SetSprite("3088083421/knsa2.png")
self:EmitSound("3088083421/soulknight/melee.mp3",511)
	if SERVER then
	local e=ents.Create("obj_308_curryq")
	e:SetPos(self:EyePos()+self:GetForward()*30)
	e:SetOwner(self)
	e:Spawn()
	e:Activate()
	e:Think()
	e:SetModelScale(2,2)
	e:GetPhysicsObject():SetVelocity((self:GetEnemy():EyePos()-self:EyePos())*2)
	SafeRemoveEntityDelayed(e,2.5)
	end
end end)
end
