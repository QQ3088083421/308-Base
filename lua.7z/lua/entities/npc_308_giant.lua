AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["giant"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.HP=150
ENT.StartSpeed=100
ENT.Scale=1.4
ENT.Att={{Range=32,dmg=15,Time=.4,SHit="Flesh.ImpactHard",SMiss="WeaponFrag.Throw"}}
ENT.MoveAct=ACT_WALK
ENT.SQuestion=_308BotNQuestion
ENT.SAnswer=_308BotNAnswer
function ENT:OnTakeDamage(d)self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav")end