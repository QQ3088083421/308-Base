AddCSLuaFile()
ENT.Base = "npc_308_man"
ENT.PrintName=GAME308_LANWEP["wargiant"]
ENT.Spawnable = true
ENT.Category = "308..' NPC"
ENT.Factions={FACTION_REBELS}
ENT.HP=1700
ENT.Scale=2.25
ENT.StartSpeed=50
ENT.Weapon="308_wm_wargiant"
ENT.Att={{dmg=65,Range=35,Time=.4,SHit="Flesh.ImpactHard",SMiss="WeaponFrag.Throw"}}
ENT.MoveAct=ACT_WALK
function ENT:OnTakeDamage()self:EmitSound("vo/npc/male01/pain0"..math.random(9)..".wav",100,70)end
